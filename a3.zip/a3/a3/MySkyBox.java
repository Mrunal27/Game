package a3;

import sage.scene.SkyBox;
import sage.scene.shape.Quad;

public class MySkyBox extends SkyBox {
	Quad [] skyboxQuads = new Quad[6];
	
}
