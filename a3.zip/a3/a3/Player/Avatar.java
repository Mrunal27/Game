package a3.Player;

import java.awt.Color;
import java.util.Stack;

import graphicslib3D.Matrix3D;
import graphicslib3D.Vector3D;
import sage.display.IDisplaySystem;
import sage.model.loader.OBJLoader;
import sage.renderer.IRenderer;
import sage.scene.SceneNode;
import sage.scene.TriMesh;
import sage.scene.bounding.BoundingVolume;
import sage.scene.shape.Sphere;
import sage.scene.shape.Teapot;
import sage.scene.state.TextureState;
import sage.scene.state.RenderState;
import sage.scene.state.RenderState.RenderStateType;
import sage.texture.Texture;
import sage.texture.TextureManager;

public class Avatar extends TriMesh {
	private Vector3D heading;
	private Matrix3D heading1 = new Matrix3D();
	
	public Avatar(IDisplaySystem display){
		//this.setColor(Color.blue);
		//this.type = this.TYPE_SOLID_TEAPOT;
		setHeading(new Vector3D(1.0,0,0));
		Vector3D vec = new Vector3D(1,0,0);
		setHeading1(0.0f,vec);
		/*
		OBJLoader loader = new OBJLoader();
		TriMesh badGuy = loader.loadModel("spider3.obj");
		//this = badGuy;
		System.out.println(badGuy.getVertexBuffer().get(0)+ "" + badGuy.getVertexBuffer().get(1)+ "" +badGuy.getVertexBuffer().get(2));
		this.setVertexBuffer(badGuy.getVertexBuffer());
		this.setTextureBuffer(badGuy.getTextureBuffer());
		this.setFaceMaterialIndices(badGuy.getFaceMaterialIndices());
		this.setIndexBuffer(badGuy.getIndexBuffer());
		this.setNormalBuffer(badGuy.getNormalBuffer());
		//this.set
		Matrix3D bgm = this.getLocalScale();
		bgm.scale(.1, .1, .1);
		this.setLocalScale(bgm);
		this.updateLocalBound();
		this.updateWorldBound();
//		addGameWorldObject(badGuy);
		
		TextureState spiderTS;
		Texture spiderT = TextureManager.loadTexture2D("MetalAircraft0061_1_M.jpg");
		spiderT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		spiderTS = (TextureState) display.getRenderer().createRenderState(RenderStateType.Texture);
		spiderTS.setTexture(spiderT, 0);
		spiderTS.setEnabled(true);
		this.setRenderState(spiderTS);//*/
		
	}

	public Vector3D getHeading() {
		return heading;
	}

	public void setHeading(Vector3D heading) {
		this.heading = heading;
	}

	public Matrix3D getHeading1() {
		return heading1;
	}

	public void setHeading1(float degrees, Vector3D axis) {
		//System.out.println("changing heading captain");
		this.heading1.rotate(degrees, axis);// = heading1;
	}

	@Override
	protected void applyRenderStatesToSceneNode(Stack<RenderState>[] arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw(IRenderer arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setLocalBound(BoundingVolume arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLocalBound() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateWorldBound() {
		// TODO Auto-generated method stub
		
	}
}
