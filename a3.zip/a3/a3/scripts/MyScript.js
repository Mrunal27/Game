var JavaPackages = new JavaImporter(
 Packages.java.awt.Color,
 Packages.sage.scene.Group,
 Packages.sage.scene.shape.Teapot,
 Packages.sage.scene.shape.Pyramid,
 Packages.sage.scene.shape.Line,
 Packages.graphicslib3D.Point3D,
 Packages.sage.model.loader.OBJLoader,
 Packages.sage.scene.TriMesh,
 Packages.java.util.Random);
with (JavaPackages)
{
	/*
var rootNode = new Group();
var t1 = new Teapot();
var x1 = Math.floor(Math.random() * 50) + 1 ;
var z1 = Math.floor(Math.random() * 50) + 1 ;
print(Math.floor(Math.random() * 6) + 1 );
rootNode.translate(x1,0,z1);
t1.translate(0,0,0);
t1.setColor(java.awt.Color.green);
rootNode.addChild(t1);
var p1 = new Pyramid();
p1.translate(0,1,0);
rootNode.addChild(p1);//*/
		var rng = new Random();
		var loader = new OBJLoader();
		var powerup = new TriMesh();
		powerup = loader.loadModel("wrench.obj");
		var bgm = powerup.getLocalScale();
		bgm.scale(.01, .01, .01);
		powerup.setLocalScale(bgm);
		var bgrm = powerup.getLocalRotation(); 
		//bgrm.rotate(-90, new Vector3D(0.0,1.0,0.0));
		powerup.setLocalRotation(bgrm);
		//var spiderTS;
		//var spiderT = TextureManager.loadTexture2D("spider2.png");
		//spiderT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		//spiderTS = display.getRenderer().createRenderState(RenderStateType.Texture);
		//spiderTS.setTexture(spiderT, 0);
		//spiderTS.setEnabled(true);
		//powerup.setRenderState(spiderTS);

		var powerupM = powerup.getLocalTranslation();
		powerupM.translate(rng.nextDouble()*400, 2.5, rng.nextDouble()*400);
		powerup.setLocalTranslation(powerupM);
		//av.updateWorldBound();
		powerup.updateLocalBound();
		powerup.updateWorldBound();
		powerup.updateGeometricState(time, true);
//		rootNode.addChild(powerup);
//		av.updateGeometricState(time, true);

//var origin = new Point3D(0,0,0);
//var xEnd = new Point3D(20,0,0);
//var yEnd = new Point3D(0,20,0);
//var zEnd = new Point3D(0,0,20);
//var xAxis = new Line(origin, xEnd, Color.red, 3);
//rootNode.addChild(xAxis);
//var yAxis = new Line(origin, yEnd, Color.green, 3);
//rootNode.addChild(yAxis);
//var zAxis = new Line(origin, zEnd, Color.blue, 3);
//rootNode.addChild(zAxis); }
 
//print("hello");
//Post-Apocalyptic Mech Spider Colosseum
}