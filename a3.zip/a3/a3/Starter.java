package a3;

import java.util.Scanner;

import myGameEngine.MyGame;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		myGame my = new myGame();
//		my.start();
		Scanner readAddress = new Scanner(System.in); //uncomment this block to reenable writing in code. for now just manual change it
		System.out.println("Enter IP Address of Host");
		String serverAddress = readAddress.nextLine();
		
		System.out.println("Enter Port Number");
		int serverPort = readAddress.nextInt();
		//*/
		MyGame myGame = new MyGame(serverAddress,6000);
		//MyGame myGame = new MyGame("10.117.81.131", 6000);
		//MyGame myGame = new MyGame("192.168.2.4",6000);
		myGame.start();
	}

}
