package a3;

public class players {
	private float wPower, sPower, mPower, armor;

	public float getwPower() {
		return wPower;
	}

	public void setwPower(float wPower) {
		this.wPower = wPower;
	}

	public float getsPower() {
		return sPower;
	}

	public void setsPower(float sPower) {
		this.sPower = sPower;
	}

	public float getmPower() {
		return mPower;
	}

	public void setmPower(float mPower) {
		this.mPower = mPower;
	}

	public float getArmor() {
		return armor;
	}

	public void setArmor(float armor) {
		this.armor = armor;
	}
	
	
}
