package a3.PowerUp;

import java.util.Random;

import graphicslib3D.Matrix3D;
import graphicslib3D.Vector3D;
import myGameEngine.PlayerHealth;
import myGameEngine.network.GhostClients;
import sage.display.IDisplaySystem;
import sage.model.loader.OBJLoader;
import sage.scene.TriMesh;
import sage.scene.state.TextureState;
import sage.scene.state.RenderState.RenderStateType;
import sage.texture.Texture;
import sage.texture.TextureManager;

public class ArmorPowerUp extends TriMesh {
	private TriMesh mesh;
	private double add = 10;
	
	public ArmorPowerUp(PlayerHealth PH, IDisplaySystem display){	
		OBJLoader loader = new OBJLoader();
		//av = new GhostClients(ghostID);
		setMesh(loader.loadModel("wrench.obj"));
		Matrix3D bgm = getMesh().getLocalScale();
		bgm.scale(.1, .1, .1);
		getMesh().setLocalScale(bgm);
		Matrix3D bgrm = getMesh().getLocalRotation(); 
		bgrm.rotate(-90, new Vector3D(0.0,1.0,0.0));
		getMesh().setLocalRotation(bgrm);
		TextureState spiderTS;
		Texture spiderT = TextureManager.loadTexture2D("spider2.png");
		spiderT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		spiderTS = (TextureState) display.getRenderer().createRenderState(RenderStateType.Texture);
		spiderTS.setTexture(spiderT, 0);
		spiderTS.setEnabled(true);
		getMesh().setRenderState(spiderTS);
		
		Matrix3D avM = getMesh().getLocalTranslation();
		Random rng = new Random();
		//avM.translate(1, 0.5, 10);
		avM.translate(rng.nextDouble()*50,.5,rng.nextDouble()*50);
		getMesh().setLocalTranslation(avM);
		//av.updateWorldBound();
		getMesh().updateLocalBound();
		getMesh().updateWorldBound();
		getMesh().updateGeometricState(1, true); //1 was time
	}

	public double getAdd() {
		return add;
	}

	public void setAdd(double add) {
		this.add = add;
	}

	public TriMesh getMesh() {
		return mesh;
	}

	public void setMesh(TriMesh mesh) {
		this.mesh = mesh;
	}
}
