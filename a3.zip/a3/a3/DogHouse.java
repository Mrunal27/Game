package a3;

import graphicslib3D.Matrix3D;
import sage.event.IEventListener;
import sage.event.IGameEvent;
import sage.scene.shape.Cube;

public class DogHouse extends Cube implements IEventListener {
	
	public DogHouse(){
		Matrix3D temp = new Matrix3D();
		int scale = 5;
		temp.scale(scale, scale, scale);
		this.setLocalScale(temp);
		
	}
	@Override
	public boolean handleEvent(IGameEvent arg0) {
		// TODO Auto-generated method stub
		//System.out.println("hmm.... doghouse?!");
		Matrix3D temp = new Matrix3D();
		int scale = 10;
		temp.scale(scale, scale, scale);
		this.setLocalScale(temp);
		
		return false;
	}
	public void returnToNormal(){
		Matrix3D temp = new Matrix3D();
		int scale=5;
		temp.scale(scale, scale, scale);
		this.setLocalScale(temp);
		
	}

}
