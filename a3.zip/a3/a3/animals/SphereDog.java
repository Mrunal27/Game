package a3.animals;

import java.awt.Color;

import a3.DogHouse;
import graphicslib3D.Matrix3D;
import myGameEngine.events.CrashEvent;
import sage.event.IEventListener;
import sage.event.IGameEvent;
import sage.scene.shape.Sphere;

public class SphereDog extends Sphere implements IEventListener{
	DogHouse DH;
	public SphereDog(DogHouse D, Color c){
		this.setColor(c);
		DH = D;
		double s = 1;
		//FloatBuffer vertBuf = com.jogamp.common.nio.Buffers.newDirectFloatBuffer(vrts);
		//FloatBuffer colorBuf = com.jogamp.common.nio.Buffers.newDirectFloatBuffer(cl);
		//IntBuffer triangleBuf = com.jogamp.common.nio.Buffers.newDirectIntBuffer(triangles);
		//this.setVertexBuffer(vertBuf);
		//this.setColorBuffer(colorBuf);
		//this.setIndexBuffer(triangleBuf); 
		Matrix3D temp = new Matrix3D();
		temp.scale(s, s, s);
		this.setLocalScale(temp);
		
	}
	
	@Override
	public boolean handleEvent(IGameEvent event){ 
		// if the event has programmer-defined information in it,
		// it must be cast to the programmer-defined event type.
		
		CrashEvent cevent = (CrashEvent) event;
		if(cevent.getWhichCrash().equals(this)){
			//if (crashCount % 2 == 0) this.setColorBuffer(colorBuffer1);
			//else this.setColorBuffer(colorBuffer2);
			//System.out.println();
			Matrix3D temp = new Matrix3D(DH.getLocalTranslation().getFloatValues()); 
			//DH.getLocalTranslation().getFloatValues();
			//temp=		DH.getLocalTranslation();
			//temp.translate(cevent.getnumber()-1.0, 0.0, 0.0);
			this.setLocalTranslation(temp);
			this.translate( (float) ((cevent.getnumber()-1)*2.0), -3.5f, 0);}
		
		return true;
	}
	
}
