package a3.animals;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import a3.DogHouse;
import graphicslib3D.Matrix3D;
import myGameEngine.events.CrashEvent;
import sage.event.IEventListener;
import sage.event.IGameEvent;
import sage.scene.TriMesh;

public class Boxer extends TriMesh implements IEventListener {
	private static float[] vrts = new float[] {(float) -.5,(float) -.5,1,(float) -.5,(float) .5,1,(float) .5,(float) .5,1,(float) .5,(float) -.5,1,(float) -.5,(float) .5,-1,(float) .5,(float) .5,-1,(float) .5,(float) -.5,-1,(float) -.5,(float) -.5,(float) -1,
			(float) -.25,(float) .5,1,(float) -.25,(float) .75,1,(float) .25,(float) .75,1,(float) .25,(float) .5,1,(float) -.25,(float) .75,0,(float) .25,(float) .75,0,(float) .25,(float) .5,0,(float) -.25,(float) .5,0};
	private static float[] cl = new float[] {1,0,0,1 ,0,1,0,1 ,0,0,1,1 ,1,1,0,1 ,1,0,1,1,1,0,0,1 ,0,1,0,1 ,0,0,1,1 ,1,1,0,1 ,1,0,1,1,1,0,0,1 ,0,1,0,1 ,0,0,1,1 ,1,1,0,1 ,1,0,1,1,0,0,0,1};
	private static int[] triangles = new int[] {0,3,1,  1,3,2, 2,3,6, 2,6,5, 1,7,0, 1,4,7, 5,6,4, 4,6,7, 0,7,3, 3,7,6, 1,2,5, 1,5,4,
			
			9,11,8, 9,11,10, 9,15,8, 9,12,15, 11,13,10, 11,14,13, 14,15,13, 13,15,12, 8,15,11, 11,15,14, 12,9,13, 13,9,10};
	private DogHouse DH;
	
	public Boxer(DogHouse d){
		DH=d;
		FloatBuffer vertBuf = com.jogamp.common.nio.Buffers.newDirectFloatBuffer(vrts);
		FloatBuffer colorBuf = com.jogamp.common.nio.Buffers.newDirectFloatBuffer(cl);
		IntBuffer triangleBuf = com.jogamp.common.nio.Buffers.newDirectIntBuffer(triangles);
		this.setVertexBuffer(vertBuf);
		this.setColorBuffer(colorBuf);
		this.setIndexBuffer(triangleBuf); 
	}
	@Override
	public boolean handleEvent(IGameEvent event) {
		// TODO Auto-generated method stub
		// if the event has programmer-defined information in it,
		// it must be cast to the programmer-defined event type.
		CrashEvent cevent = (CrashEvent) event;
			
		//System.out.println("I have a crash");	
		//int crashCount = cevent.getWhichCrash();
		if(cevent.getWhichCrash().equals(this)){
		//if (crashCount % 2 == 0) this.setColorBuffer(colorBuffer1);
		//else this.setColorBuffer(colorBuffer2);
		//
		Matrix3D temp = new Matrix3D(DH.getLocalTranslation().getFloatValues()); 
		//DH.getLocalTranslation().getFloatValues();
		//temp=		DH.getLocalTranslation();
		//temp.translate(cevent.getnumber()-1.0, 0.0, 0.0);
		this.setLocalTranslation(temp);
		this.translate((float) ( ((cevent.getnumber())-1.0)*2.0), -3.5f, 0);}
		return true;
	}

}
