package a3.animals;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import a3.DogHouse;
import graphicslib3D.Matrix3D;
import myGameEngine.events.CrashEvent;
import sage.event.IEventListener;
import sage.event.IGameEvent;
import sage.scene.TriMesh;

public class Spikey extends TriMesh  implements IEventListener {
	/*
	 * This section contains code supplied by Dr Gordon.  Nearly everything in this class.
	 */
	//		1		2		3		  4		    5
	private static float[] vrts = new float[] {0,1,0  ,-1,-1,1  ,1,-1,1  ,1,-1,-1  ,-1,-1,-1};
	private static float[] cl = new float[] {1,0,0,1  ,0,1,0,1  ,0,0,1,1 ,1,1,0,1  ,1,0,1,1};
	private static int[] triangles = new int[] {0,1,2, 0,2,3,   0,3,4    ,0,4,1     ,1,4,2    ,4,3,2};
	private DogHouse DH;
	
	public Spikey(DogHouse D){
		DH = D;
		double s = .2;
		
		FloatBuffer vertBuf = com.jogamp.common.nio.Buffers.newDirectFloatBuffer(vrts);
		FloatBuffer colorBuf = com.jogamp.common.nio.Buffers.newDirectFloatBuffer(cl);
		IntBuffer triangleBuf = com.jogamp.common.nio.Buffers.newDirectIntBuffer(triangles);
		this.setVertexBuffer(vertBuf);
		this.setColorBuffer(colorBuf);
		this.setIndexBuffer(triangleBuf); 
		Matrix3D temp = new Matrix3D();
		temp.scale(s, s, s);
	}

	@Override
	 public boolean handleEvent(IGameEvent event){ 
		// if the event has programmer-defined information in it,
		// it must be cast to the programmer-defined event type.
		CrashEvent cevent = (CrashEvent) event;
		
		
		//int crashCount = cevent.getWhichCrash();
		if(cevent.getWhichCrash().equals(this)){
		//if (crashCount % 2 == 0) this.setColorBuffer(colorBuffer1);
		//else this.setColorBuffer(colorBuffer2);
		//System.out.println();
		Matrix3D temp = new Matrix3D(DH.getLocalTranslation().getFloatValues()); 
		//DH.getLocalTranslation().getFloatValues();
		//temp=		DH.getLocalTranslation();
		//temp.translate(cevent.getnumber()-1.0, 0.0, 0.0);
		this.setLocalTranslation(temp);
		this.translate((float) ( ((cevent.getnumber())-1.0)*2.0), -3.5f, 0);}
		return true;
	}
}
