package myGameEngine;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JOptionPane;

import myGameEngine.network.MyClient;

public class CustomWindowListener implements WindowListener{

	private MyClient myClient;
	private MyGame myGame;

	public CustomWindowListener(MyGame myGame, MyClient client)
	{
		super();
		this.myClient = client;
		this.myGame = myGame;
	}
	public CustomWindowListener() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		int result = JOptionPane.showConfirmDialog
				(e.getWindow(), 						
					"Are you sure you want to exit ?", 
					"Confirm Exit", 
					JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE);
			
					if (result == JOptionPane.YES_OPTION) { 
						
						//myGame.byeMessage();
						myGame.quitGame();
						
					}
					else
					{
						return; 
					}
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
