package myGameEngine;

import java.awt.Color;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import graphicslib3D.Matrix3D;
import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import net.java.games.input.ControllerEnvironment;
import sage.app.BaseGame;
import sage.audio.AudioManagerFactory;
import sage.audio.AudioResource;
import sage.audio.AudioResourceType;
import sage.audio.IAudioManager;
import sage.audio.Sound;
import sage.audio.SoundType;
import sage.camera.ICamera;
import sage.camera.JOGLCamera;
import sage.display.IDisplaySystem;
import sage.event.EventManager;
import sage.event.IEventManager;
import sage.input.IInputManager;
import sage.input.InputEvent;
import sage.input.InputManager;
import sage.input.action.IAction;
import sage.networking.IGameConnection.ProtocolType;
import sage.physics.IPhysicsEngine;
import sage.physics.IPhysicsObject;
import sage.physics.PhysicsEngineFactory;
import sage.renderer.IRenderer;
import net.java.games.input.Component;
import net.java.games.input.Controller;
import sage.scene.Group;
import sage.scene.HUDString;
import sage.scene.Model3DTriMesh;
import sage.scene.SceneNode;
import sage.scene.SkyBox;
import sage.scene.SkyBox.Face;
//import sage.scene.Controller;
import sage.scene.shape.Line;
import sage.scene.shape.Quad;
import sage.scene.shape.Square;
import sage.scene.state.RenderState;
import sage.scene.state.RenderState.RenderStateType;
import sage.scene.state.TextureState;
import sage.scene.state.ZBufferState;
import sage.terrain.AbstractHeightMap;
import sage.terrain.ImageBasedHeightMap;
import sage.terrain.HillHeightMap;
import sage.display.DisplaySettingsDialog;

import sage.terrain.TerrainBlock;
import sage.texture.Texture;
import sage.texture.TextureManager;

import java.util.Random;
import java.util.UUID;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineFactory;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

//import a3.DogHouse;
import a3.PowerUp.ArmorPowerUp;
//import a3.Player.Avatar;
import a3.animals.Boxer;
import a3.animals.SphereDog;
import a3.animals.Spikey;
import myGameEngine.commands.Pan;
//import myGameEngine.commands.Roll;
//import myGameEngine.commands.RollRight;
import myGameEngine.commands.CamZoom;
import myGameEngine.commands.Forward;
import myGameEngine.commands.Jump;
import myGameEngine.commands.ObitShiftRotation;
import myGameEngine.commands.OrbitAroundAction;
import myGameEngine.commands.OrbitElevation;
import myGameEngine.events.CrashEvent;
import myGameEngine.network.GhostAvatar;
import myGameEngine.network.MyClient;
//import myGameEngine.network.MySphere;
import myGameEngine.network.NPC;
import myGameEngine.network.NPCcontroller;
import myGameEngine.nodeController.Doubler;
import myGameEngine.nodeController.dogrotater;
import myGameEngine.nodeController.moonrotater;
import myGameEngine.nodeController.moontranslater;
import myGameEngine.MyScore;
import myGameEngine.MyTime;
import sage.model.loader.OBJLoader;
import sage.model.loader.ogreXML.OgreXMLParser;
import sage.scene.TriMesh;

public class MyGame extends BaseGame {
	private int frameWidth = 1024;
	private int frameHeight = 768;
	private boolean isFullScreenMode = false;
	
	IDisplaySystem display;// = new MyDisplayplaySystem();
	ICamera camera, camera2;
	IEventManager eventMgr;
	Camera3Pcontroller cc;//, cc2;
	private int score=0, score2 = 0 ;
	private float time = 0 ; // game elapsed time
//	private Spikey aPyr;
//	private DogHouse DH;
//	private SphereDog sd;
	private TriMesh gun;
	private MyScore ms= new MyScore("Dogs caught = " + score), ms2= new MyScore("Dogs caught = " + score2);
	private MyTime mt = new MyTime ("Time = " + time);
	private Boxer aAnimal; //= new myAnimal(DH);
	//public TriMesh av;
//	private Avatar av2;
	//private Square plane;
	private Group dogs;
	private float timer2,timersound;
	private Group PowerUp = new Group();
	private SkyBox sb;
//	private String scriptFileName = "bin" +"\\" + "a3" + "\\" +"scripts" +"\\" +"Hello.js";
	private String scriptFileName = "bin" +"\\" + "a3" + "\\" +"scripts" +"\\" +"MyScript.js";
//	private String scriptFileName = "a3" + "\\" +"scripts" +"\\" +"Hello.js";
	
	private ScriptEngineManager factory = new ScriptEngineManager();
	private ScriptEngine jsEngine = factory.getEngineByName("js");
//	this.executeScript(jsEngine,scriptFileName);
	private String serverAddress;
	private int sPort;
	private ProtocolType protocolType;
	private MyClient myClient;
	
	private TerrainBlock hillTerrain;
	private IRenderer renderer;
	private SceneNode rootnode;
	//private ThirdPersonCameraController cam1Controller, cam2Controller;
	//private MySphere ghostSphere;
	private ArrayList<GhostAvatar> ghostAvatars;
	private ArrayList<NPC> npcGuns = new ArrayList<NPC>();
	
	private IPhysicsEngine physicsEngine;
	private IPhysicsObject boxP, groundPlaneP;
	private boolean isConnected = false;
	private IAudioManager audioMgr;
	Sound waterSound;
	private Sound npcSound; 
	private GraphicsDevice device;
	TriMesh moon1, moon2;
	Group moon = new Group();
	Group moonhalf1 = new Group();
	Group moonhalf2 = new Group();
	
	TriMesh ghostAvatar;
	Group ghostAvatarGroup;
	Group npcGroup = new Group();
	NPC npc = null;
	private AudioResource resource1;
	AudioResource resource2;
	PlayerHealth playerHealth= new PlayerHealth();
	Group av = new Group();
	private MyScore shield = new MyScore("Dogs caught = " + score);
	private MyScore armor= new MyScore("Dogs caught = " + score2);
	boolean gunfiring = false;
	
	public MyGame(String serverAddress,int sPort){
		super();
		this.serverAddress = serverAddress;
		this.sPort = sPort;
		this.protocolType = ProtocolType.TCP;
		timer2=time;
	}
	
	private void executeScript(ScriptEngine engine, String scriptFileName){
		//engine.put("PH", playerHealth);
		//engine.put("display", display);
		
		try{ 
			FileReader fileReader = new FileReader(scriptFileName);
			engine.eval(fileReader); //execute the script statements in the file
			fileReader.close();
		}
		catch (FileNotFoundException e1){ 
			System.out.println(scriptFileName + " not found " + e1); }
		catch (IOException e2){ 
			System.out.println("IO problem with " + scriptFileName + e2); }
		catch (ScriptException e3){ 
				System.out.println("ScriptException in " + scriptFileName + e3); }
		catch (NullPointerException e4)
		{ System.out.println ("Null ptr exception in " + scriptFileName + e4); }
	}

	
	/*private IDisplaySystem initDisplaySystem(){
		 
		 IDisplaySystem display = new MyDisplayplaySystem(1920, 1080, 32, 60, true,
				 "sage.renderer.jogl.JOGLRenderer");
				 System.out.print("\nWaiting for display creation...");
		 
		 int count = 0;
		 // wait until display creation completes or a timeout occurs
		 while (!display.isCreated())
		 {
		 try
		 { Thread.sleep(10); }
		 catch (InterruptedException e)
		 { throw new RuntimeException("Display creation interrupted"); }
		 count++;
		 System.out.print("+");
		 if (count % 80 == 0) { System.out.println(); }
		 if (count > 2000) // 20 seconds (approx.)
		 { throw new RuntimeException("Unable to create display");
		 }
		 }
		 System.out.println();
		 return display;
	 }//*/
	 
	protected void initSystem()
	{ //call a local method to create a DisplaySystem object
		
		display = createDisplaySystem();
		renderer = display.getRenderer();
		setDisplaySystem(display);
		
		
		/*IDisplaySystem display = initDisplaySystem();
		setDisplaySystem(display);//*/
		//create an Input Manager
		IInputManager inputManager = new InputManager();
		setInputManager(inputManager);
		//create an (empty) gameworld
		ArrayList<SceneNode> gameWorld = new ArrayList<SceneNode>();
		setGameWorld(gameWorld);
	}

	 
	protected void initGame(){ 
		initClient();
		//display = initDisplaySystem();
		//renderer = getDisplaySystem().getRenderer();
		
		eventMgr = EventManager.getInstance();
		initGameObects();
		mt.setLocation(0.0, .05);
		camera.addToHUD(mt);
		shield.setLocation(0.0,0.9);
		armor.setLocation(.17,0.9);
		shield.setColor(Color.gray);
		armor.setColor(Color.gray);
		camera.addToHUD(shield);
		camera.addToHUD(armor);
		mt.setColor(Color.gray);
		
		/*
		 * This section contains code supplied by Dr Gordon
		 */
		
		IInputManager im = getInputManager();
		String gpName = im.getFirstGamepadName();
		String kbName = im.getKeyboardName();
//		kbName="Standard PS/2 Keyboard";		
		ControllerEnvironment ce = ControllerEnvironment.getDefaultEnvironment();
		Controller[] cs = ce.getControllers();
/*		for (int i=0; i < cs.length; i++)
		{
			System.out.println("\nController #" + i);
			listComponents(cs[i]);
		} //*/
		Forward mvForward = new Forward(av,hillTerrain, myClient); //, setSpeed);
	//	Pan mvPan = new Pan(av, hillTerrain);
		myGameEngine.commands.Exit myexit = new myGameEngine.commands.Exit(this);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.W, mvForward, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.S, mvForward, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
	//	im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.A, mvPan, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
	//	im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.D, mvPan, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.UP, mvPitchUp, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.DOWN, mvPitch, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.LEFT, mvYaw, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.RIGHT, mvYawRight, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.Q, mvRoll, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.E, mvRollRight, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.ESCAPE, myexit, IInputManager.INPUT_ACTION_TYPE.ON_PRESS_ONLY);
		
		cc=new Camera3Pcontroller(camera,(SceneNode)av,im,kbName);
		IAction orbitAction = new OrbitAroundAction(cc,av);
		IAction orbitEleAction = new OrbitElevation(cc);
		CamZoom cz = new CamZoom(cc);
		ObitShiftRotation osr2 = new ObitShiftRotation((OrbitAroundAction) orbitAction);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.UP, orbitEleAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.DOWN, orbitEleAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.LEFT, orbitAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.RIGHT, orbitAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.LSHIFT, osr2, IInputManager.INPUT_ACTION_TYPE.ON_PRESS_AND_RELEASE);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.E, cz, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.Q, cz, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		Jump jumpAction = new Jump(av);
		
		if (im.getFirstGamepadName()!=null){
			cc=new Camera3Pcontroller(camera,(SceneNode)av,im,gpName);
			//CamZoom cz = new CamZoom(cc);
			orbitAction = new OrbitAroundAction(cc,av);
			orbitEleAction = new OrbitElevation(cc);
			ObitShiftRotation osr = new ObitShiftRotation((OrbitAroundAction) orbitAction);
			//System.out.println(gpName);
			im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.Y,mvForward,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			//im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.Y,mvBackward,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		//	im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.X,mvPan,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			//im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.X,mvPanRight,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			//im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.RY,mvPitch,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			//im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.RY,mvPitchUp,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			//im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.RX,mvYaw,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			//im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.RX,mvYawRight,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
//			im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.Z,mvRoll,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
//			im.associateAction(gpName,net.java.games.input.Component.Identifier.Axis.Z,mvRollRight,IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Axis.RX, orbitAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Axis.RY, orbitEleAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Axis.Z, cz, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Button._4, osr, IInputManager.INPUT_ACTION_TYPE.ON_PRESS_AND_RELEASE);
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Button._0, jumpAction, IInputManager.INPUT_ACTION_TYPE.ON_PRESS_ONLY);
			//*/
		}
		//String mouse="Lenovo Pointing Device";  //im.getMouseName();
		initPhysicsSystem();
		createSagePhysicsWorld();
		initAudio();
	}
	
	
	private void initAudio() {
		// TODO Auto-generated method stub
		
		setAudioMgr(AudioManagerFactory.createAudioManager("sage.audio.joal.JOALAudioManager"));
		if(!getAudioMgr().initialize()){
			System.out.println("Audio Manager failed to initialize!");
			return;
		}
		setResource1(getAudioMgr().createAudioResource("bin" +"\\" + "a3" + "\\" + "sounds" + "\\" +"104401_kantouth_gatling-gun.wav",
		AudioResourceType.AUDIO_SAMPLE));
//		resource2 = audioMgr.createAudioResource("a3" + "\\" + "sounds" + "\\" +"water.wav",
//		AudioResourceType.AUDIO_SAMPLE);
		setNpcSound(new Sound(getResource1(), SoundType.SOUND_EFFECT, 100, true));
//		waterSound =new Sound(resource2, SoundType.SOUND_EFFECT, 100, true);
		getNpcSound().initialize(getAudioMgr());
		//getNpcSound().
//		waterSound.initialize(audioMgr);
		if (getNpcSound()==null){
			System.out.println("npc is null");
		}
		getNpcSound().setMaxDistance(30.0f);
		getNpcSound().setMinDistance(3.0f);
		getNpcSound().setRollOff(5.0f);
//		waterSound.setMaxDistance(50.0f);
//		waterSound.setMinDistance(3.0f);
//		waterSound.setRollOff(5.0f);
		//getNpcSound().setLocation(new Point3D(gun.getWorldTranslation().getCol(3)));
//		waterSound.setLocation(new Point3D(tp.getWorldTranslation().getCol(3)));
		setEarParameters();
		//sdlfgjknsdfkl;
		//getNpcSound().play();
//		waterSound.play();
	}

	private void setEarParameters() {
		// TODO Auto-generated method stub
		Matrix3D avDir = (Matrix3D) (av.getWorldRotation().clone());
		float camAz = cc.getCameraAzimuth();
		
		avDir.rotateY(180.0f-camAz);
		Vector3D camDir = new Vector3D(0,0,1);
		camDir = camDir.mult(avDir);
		getAudioMgr().getEar().setLocation(camera.getLocation());
		getAudioMgr().getEar().setOrientation(camDir, new Vector3D(0,1,0));
	}

	public void initPhysicsSystem(){
		String engine = "sage.physics.JBullet.JBulletPhysicsEngine";
		physicsEngine = PhysicsEngineFactory.createPhysicsEngine(engine);
		physicsEngine.initSystem();
		float[] gravity = {0.0f, -1.0f, 0.0f};
		physicsEngine.setGravity(gravity);
	}
	
	public void createSagePhysicsWorld(){
		float mass = 0.9f;
		double[] a = av.getWorldTransform().getValues();
	/*	System.out.print(a[0]+ " ");
		System.out.print(a[1]+ " ");
		System.out.print(a[2]+ " ");
		System.out.print(a[3]+ " "); System.out.println("");
		System.out.print(a[4]+ " "); 
		System.out.print(a[5]+ " ");
		System.out.print(a[6]+ " ");
		System.out.print(a[7]+ " "); System.out.println("");
		System.out.print(a[8]+ " "); 
		System.out.print(a[9]+ " ");
		System.out.print(a[10]+ " ");
		System.out.print(a[11]+ " "); System.out.println("");
		System.out.print(a[12]+ " ");
		System.out.print(a[13]+ " ");
		System.out.print(a[14]+ " ");
		System.out.print(a[15]+ " ");//*/
		float[] temp = {1.0f,1.0f,1.0f};
		boxP = physicsEngine.addBoxObject(physicsEngine.nextUID(), mass, av.getWorldTransform().getValues(), temp);
		//System.out.println(av.getWorldTranslation().getValues());
		boxP.setBounciness(0.00f);
		//boxP.setLinearVelocity(new float[] {0.0f,0.0f,0.0f});
		boxP.setFriction(1.0f); //changed
		boxP.setSleepThresholds(.0000001f, .0000001f);
		av.setPhysicsObject(boxP);
		float up[] = {0.0f,1.0f,0f};
		groundPlaneP = physicsEngine.addStaticPlaneObject(physicsEngine.nextUID(), hillTerrain.getWorldTransform().getValues(), up, 0.0f);
		groundPlaneP.setFriction(1.0f); //changed
		groundPlaneP.setBounciness(0.0f);
		a = groundPlaneP.getTransform();
		a[13]=3.5;
		groundPlaneP.setTransform(a);
		hillTerrain.setPhysicsObject(groundPlaneP);
	}
	
	public void initGameObects(){
		/*
		 * This section contains code supplied by Dr Gordon
		 */
		//IDisplaySystem display = getDisplaySystem();
		//display.setTitle("3D dog catcher");
//		camera = display.getRenderer().getCamera();
		camera=new JOGLCamera(renderer);
		camera.setPerspectiveFrustum(30, 1, 0.01, 1000);
		camera.setLocation(new Point3D(1, 3, 20));
		camera.setViewport(0.0, 1.0, 0.0, 1.0);
		Random rng = new Random();
		
		camera2 = new JOGLCamera(renderer);
		camera2.setPerspectiveFrustum(60, 2, 1, 1000);
		camera2.setViewport(0.0, 1.0, 0.55, 1.0);
		camera2.setLocation(new Point3D(1,1,0));
		
		sb = new SkyBox("skybox",20.f,20.0f,20.0f);
		//Quad North = sb.getFace(SkyBox.Face.North);
		Texture tex1 = TextureManager.loadTexture2D("bin"+"\\"+"a3"+"\\"+"images"+"\\"+"skyrender0005.jpg");
		Texture tex2 = TextureManager.loadTexture2D("bin"+"\\"+"a3"+"\\"+"images"+"\\"+"skyrender0001.jpg");
//		Texture tex2 = TextureManager.loadTexture2D("a3"+"\\"+"images"+"\\"+"skyrender0001.jpg");
		
		//East.setTexture(tex2);
		//Quad South = sb.getFace(SkyBox.Face.South);
		Texture tex3 = TextureManager.loadTexture2D("bin"+"\\"+"a3"+"\\"+"images"+"\\"+"skyrender0002.jpg");
//		Texture tex3 = TextureManager.loadTexture2D("a3"+"\\"+"images"+"\\"+"skyrender0002.jpg");
		
		//South.setTexture(tex3);
		//Quad West = sb.getFace(SkyBox.Face.West);
		Texture tex4 = TextureManager.loadTexture2D("bin"+"\\"+"a3"+"\\"+"images"+"\\"+"skyrender0004.jpg");
//		Texture tex4 = TextureManager.loadTexture2D("a3"+"\\"+"images"+"\\"+"skyrender0004.jpg");
		
		//West.setTexture(tex4);
		//Quad Up = sb.getFace(SkyBox.Face.Up);
		Texture tex5 = TextureManager.loadTexture2D("bin"+"\\"+"a3"+"\\"+"images"+"\\"+"skyrender0005.jpg");
//		Texture tex5 = TextureManager.loadTexture2D("a3"+"\\"+"images"+"\\"+"skyrender0003.jpg");
		
		//Up.setTexture(tex5);
		//Quad Down = sb.getFace(SkyBox.Face.Down);
		Texture tex6 = TextureManager.loadTexture2D("bin"+"\\"+"a3"+"\\"+"images"+"\\"+"skyrender0006.jpg");
//		Texture tex6 = TextureManager.loadTexture2D("a3"+"\\"+"images"+"\\"+"skyrender0006.jpg");
		
		//South.setTexture(tex6);
		sb.setTexture(SkyBox.Face.North, tex1);
		sb.setTexture(SkyBox.Face.East, tex2);
		sb.setTexture(SkyBox.Face.South, tex3);
		sb.setTexture(SkyBox.Face.West, tex4);
		sb.setTexture(SkyBox.Face.Up, tex5);
		sb.setTexture(SkyBox.Face.Down, tex6);
		
		
		ZBufferState zbuff = (ZBufferState) display.getRenderer().createRenderState(RenderStateType.ZBuffer);
		zbuff.setWritable(false); // OpenGL equivalent: glDepthMask(false);
		zbuff.setDepthTestingEnabled(false); // OpenGL equivalent: glDisable(GL_DEPTH_TEST)
		zbuff.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
		zbuff.setEnabled(true);
		sb.setRenderState(zbuff);
		sb.updateRenderStates();
		addGameWorldObject(sb);
		//*/
		//sb.setZBufferStateEnabled(false);
		
		OBJLoader loader = new OBJLoader();
		OgreXMLParser loader2 = new OgreXMLParser();
		
		//av = new TriMesh();
		//av = loader.loadModel("spider3.obj");
		/*
		//addGameWorldObject(avmodel);
		Matrix3D bgm = av.getLocalScale();
		bgm.scale(.1, .1, .1);
		av.setLocalScale(bgm);
		Matrix3D bgrm = av.getLocalRotation(); 
		bgrm.rotate(-90, new Vector3D(0.0,1.0,0.0));
		av.setLocalRotation(bgrm);
		TextureState spiderTS;
		Texture spiderT = TextureManager.loadTexture2D("spider2.png");
		spiderT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		spiderTS = (TextureState) display.getRenderer().createRenderState(RenderStateType.Texture);
		spiderTS.setTexture(spiderT, 0);
		spiderTS.setEnabled(true);
		av.setRenderState(spiderTS);

		Matrix3D avM = av.getLocalTranslation();
		avM.translate(1, 2.5, 10);
		av.setLocalTranslation(avM);
		//av.updateWorldBound();
		av.updateLocalBound();
		av.updateWorldBound();
		addGameWorldObject(av);
		av.updateGeometricState(time, true);
		double[] a = av.getLocalTranslation().getValues();//*/
		try {
			av = loader2.loadModel("spider3.mesh.xml","lambert10SG.material","spider3.skeleton.xml");
			//test.updateGeometricState(0, true);
			Matrix3D bgm = av.getLocalScale();
			bgm.scale(.1, .1, .1);
			Matrix3D bgrm = av.getLocalRotation(); 
			bgrm.rotate(-90, new Vector3D(0.0,1.0,0.0));
			Matrix3D avM = av.getLocalTranslation();
			avM.translate(1, 2.5, 10);
			av.setLocalTranslation(avM);
			
			av.setLocalScale(bgm);
			av.setLocalTranslation(avM);
			av.setLocalRotation(bgrm);
			av.updateGeometricState(0, true);
			//avmodel.setRenderState(spiderTS);
			
			addGameWorldObject(av);
			
			Iterator<SceneNode> itr = av.getChildren();
			while (itr.hasNext())
			{ Model3DTriMesh mesh = ((Model3DTriMesh)itr.next());
			mesh.startAnimation("Jumping");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		loader = new OBJLoader();
		gun = loader.loadModel("gun.obj");
		Matrix3D gm = gun.getLocalScale();
		gm.scale(.1, .1, .1);
		gun.setLocalScale(gm);
		TextureState gunTS;
		Texture gunT = TextureManager.loadTexture2D("CamoColor.jpg");
		gunT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		gunTS = (TextureState) display.getRenderer().createRenderState(RenderStateType.Texture);
		gunTS.setTexture(gunT, 0);
		gunTS.setEnabled(true);
		gun.setRenderState(gunTS);
		
		//av = new Avatar(display);
		Matrix3D gunM = gun.getLocalTranslation();
		gunM.translate(1, .5, 20);
		gun.setLocalTranslation(gunM);
		gun.updateWorldBound();
		gun.updateLocalBound();
		//av.updateWorldBound();
		addGameWorldObject(gun);
		
//		DH = new DogHouse();
//		Matrix3D DHM = DH.getLocalTranslation();
//		DHM.translate(10, 5, 0);
//		DH.setLocalTranslation(DHM);
//		Doubler dogdoubler = new Doubler(DH);
//		DH.addController(dogdoubler);
//		addGameWorldObject(DH);
//		eventMgr.addListener(DH, CrashEvent.class);
		
		
//		addGameWorldObject(badGuy);
/*		plane = new Square();
		plane.setColor(Color.GREEN);
		Matrix3D plnM = new Matrix3D();
		plnM.rotate(90, 0, 0);
		plane.setLocalRotation(plnM);
		plnM = new Matrix3D();
		plnM.scale(100, 100, 0);
		plane.setLocalScale(plnM);
		plnM = new Matrix3D();
		plnM.translate(50, 0, 50);
		plane.setLocalTranslation(plnM);
		
		addGameWorldObject(plane);
		//*/
		dogs= new Group();
		
		dogrotater drr = new dogrotater();
		moonrotater mrr = new moonrotater();
		moontranslater mtr = new moontranslater();
//		sd = new SphereDog(DH, Color.GRAY);
//		Matrix3D sdM = sd.getLocalTranslation();
//		sdM.translate(rng.nextDouble()*400,.5,rng.nextDouble()*400);
//		sd.setLocalTranslation(sdM);
//		addGameWorldObject(sd);
//		dogs.addChild(sd);
//		sd.addController(drr);
//		eventMgr.addListener(sd, CrashEvent.class);
		drr.addControlledNode(PowerUp);
		moon1 = loader.loadModel("brokenmoon.obj");
		moon2 = loader.loadModel("brokenmoon.obj");
		
		Matrix3D mm1 = moonhalf1.getLocalTranslation();
		Matrix3D mm2 = moonhalf2.getLocalTranslation();
		Matrix3D mm2r = moonhalf2.getLocalRotation();
		Matrix3D moonm = moon.getLocalTranslation();
		mm2r.rotate(-180, new Vector3D(1.0,0.0,0.0));
		mm1.translate(0.0, .2, 0.0);
		mm2.translate(0.0, -.2, 0.0);
		moonhalf1.setLocalTranslation(mm1);
		moonhalf2.setLocalTranslation(mm2);
		moonhalf2.setLocalRotation(mm2r);
		moon1.setLocalTranslation(mm1);
		moon2.setLocalTranslation(mm2);
		moonm.translate(0, 5, 30);
		moon.setLocalTranslation(moonm);
		moon1.setIsTransformSpaceParent(true);
		moon2.setIsTransformSpaceParent(true);
		moonhalf1.setIsTransformSpaceParent(true);
		moonhalf2.setIsTransformSpaceParent(true);
		moon.setIsTransformSpaceParent(true);
		
		moonhalf1.addChild(moon1);
		moonhalf2.addChild(moon2);
		moon.addChild(moonhalf1);
		moon.addChild(moonhalf2);
		addGameWorldObject(moon);
		
		mrr.addControlledNode(moon);
		mrr.addControlledNode(moonhalf1);
		mrr.addControlledNode(moonhalf2);
		mtr.addControlledNode(moonhalf1);
		mtr.addControlledNode(moonhalf2);
		
		moon1.addController(mtr);
		moon2.addController(mtr);
		moonhalf1.addController(mrr);
		moonhalf2.addController(mrr);
		moon.addController(mrr);
		//moon1.addController(mrr);
		//moon2.addController(mrr);
/*		//System.out.println("hi");
		aPyr = new Spikey(DH);
		Matrix3D pyrM = aPyr.getLocalTranslation();
		pyrM.translate(rng.nextDouble()*50,.5,rng.nextDouble()*50);
		aPyr.setLocalTranslation(pyrM);
//		addGameWorldObject(aPyr);
//		aPyr.addController(drr);
		dogs.addChild(aPyr);
		eventMgr.addListener(aPyr, CrashEvent.class);
		//event creation
		//CrashEvent cevent = new CrashEvent();
		*/
		
		//animals creation
		/*
		teap = new Teapot(Color.blue);
		Matrix3D teaM = teap.getLocalTranslation();
		teaM.translate(-1,1,-5);
		teap.setLocalTranslation(teaM);
		
		addGameWorldObject(teap);
		
		Cube square = new Cube();
		Matrix3D squarem = square.getLocalTranslation();
		squarem.translate(rng.nextInt()%10,rng.nextInt()%10,rng.nextInt()%10);
		square.setLocalTranslation(squarem);
		
		addGameWorldObject(square);
		//*/
		
		addGameWorldObject(PowerUp);
//		aAnimal = new Boxer(DH);
//		Matrix3D animaM = aAnimal.getLocalTranslation();
//		animaM.translate(rng.nextDouble()*50, .5, rng.nextDouble()*50);
//		aAnimal.setLocalTranslation(animaM);
//		aAnimal.addController(drr);
//		dogs.addChild(aAnimal);
//		addGameWorldObject(aAnimal);
//		eventMgr.addListener(aAnimal, CrashEvent.class);
		
		/*
		 * This section contains code supplied by Dr Gordon
		 */
		//Point3D origin = new Point3D(0,0,0);
		//Point3D xEnd = new Point3D(100,0,0);
		//Point3D yEnd = new Point3D(0,100,0);
		//Point3D zEnd = new Point3D(0,0,100);
		//Line xAxis = new Line (origin, xEnd, Color.red, 2);
		//Line yAxis = new Line (origin, yEnd, Color.green, 2);
		//Line zAxis = new Line (origin, zEnd, Color.blue, 2);
		//addGameWorldObject(xAxis); addGameWorldObject(yAxis);
		//addGameWorldObject(zAxis);
		//eventMgr.addListener(teap, CrashEvent.class);
		addGameWorldObject(dogs);
		dogs.addController(drr);
		initTerrain();
	}
	
	private void initTerrain(){ // create height map and terrain block
		
		HillHeightMap myHillHeightMap = new HillHeightMap(400, 2000, 5.0f, 20.0f,(byte)2, 59);
		myHillHeightMap.setHeightScale(91f);
		hillTerrain = createTerBlock(myHillHeightMap);
		// create texture and texture state to color the terrain
		TextureState grassState;
//		Texture grassTexture = TextureManager.loadTexture2D("a3"+"\\"+"images"+"\\"+"grass.jpg");
		Texture grassTexture = TextureManager.loadTexture2D("bin" + "\\" + "a3"+"\\"+"images"+"\\"+"grass.jpg");
		//Texture grassTexture = TextureManager.loadTexture2D("grass.jpg");
		grassTexture.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		grassState = (TextureState)
		display.getRenderer().createRenderState(RenderState.RenderStateType.Texture);
		grassState.setTexture(grassTexture,0);
		grassState.setEnabled(true);
		// apply the texture to the terrain
		hillTerrain.setRenderState(grassState);
		hillTerrain.translate(0f, 0f, 0f);
		addGameWorldObject(hillTerrain);
		
		
	}
	
	private TerrainBlock createTerBlock(AbstractHeightMap heightMap){ 
		//float heightScale = .009f;
		
		float heightScale = .015f;
		Vector3D terrainScale = new Vector3D(1, heightScale, 1);
		// use the size of the height map as the size of the terrain
		int terrainSize = heightMap.getSize();
		// specify terrain origin so heightmap (0,0) is at world origin
		float cornerHeight = heightMap.getTrueHeightAtPoint(0, 0) * heightScale;
		Point3D terrainOrigin = new Point3D(0, -cornerHeight, 0);
		// create a terrain block using the height map
		String name = "Terrain:" + heightMap.getClass().getSimpleName();
		TerrainBlock tb = new TerrainBlock(name, terrainSize, terrainScale,
		heightMap.getHeightData(), terrainOrigin);
		return tb;
		
		
	}
	 
	public void update(float  elapsedTimeMS){
		cc.update(elapsedTimeMS);
		//cc2.update(elapsedTimeMS);
		
		sb.setLocalTranslation(av.getLocalTranslation());
		super.update( elapsedTimeMS);
//		getGameWorld().iterator();
		Iterator<SceneNode> it; // =  dogs.iterator();    //getGameWorld().iterator();
		SceneNode holder = null;
		Matrix3D mat;
		Vector3D translateVec;
		
		double[] a = groundPlaneP.getTransform();
		/*System.out.println("");
		System.out.println("");
		System.out.print(a[0]+ " ");
		System.out.print(a[1]+ " ");
		System.out.print(a[2]+ " ");
		System.out.print(a[3]+ " "); System.out.println("");
		System.out.print(a[4]+ " "); 
		System.out.print(a[5]+ " ");
		System.out.print(a[6]+ " ");
		System.out.print(a[7]+ " "); System.out.println("");
		System.out.print(a[8]+ " "); 
		System.out.print(a[9]+ " ");
		System.out.print(a[10]+ " ");
		System.out.print(a[11]+ " "); System.out.println("");
		System.out.print(a[12]+ " ");
		System.out.print(a[13]+ " "); // the one that deals with height
		System.out.print(a[14]+ " ");
		System.out.print(a[15]+ " "); System.out.println("");
		*/Point3D avLoc = new Point3D(av.getLocalTranslation().getCol(3));
		float x = (float) avLoc.getX();
		float z = (float) avLoc.getZ();
		//if (terrain==null){System.out.println("terHeight is null");}
		//System.out.println(x + " "+ z);
		
		//System.out.println(terrain.getSize());
		a[13] = hillTerrain.getHeight(x,z);
		Matrix3D temp = hillTerrain.getLocalTranslation();
		temp.translate(0, a[13], 0);
		groundPlaneP.setTransform(a);
		
		physicsEngine.update(elapsedTimeMS);
/*		while(holder!=null){
			//if (av.getWorldBound()==null){
			//	System.out.println("av is null");
			//}
			if (//(holder.getClass().getSuperclass()!=HUDString.class && holder.getClass()!=Line.class&& holder.getClass()!=DogHouse.class&& holder.getClass()!=Square.class && holder.getClass() != Avatar.class) &&
				
				holder.getWorldBound().intersects(av.getWorldBound())){   //)&& !holder.equals(av)){
				//CrashEvent newCrash = new CrashEvent(1);
				//eventMgr.triggerEvent(newCrash);
				//System.out.println(holder.getName());
//				score++;
//				CrashEvent newCrash = new CrashEvent(holder,score+score2);
//				eventMgr.triggerEvent(newCrash);
				//System.out.println("the time at the crash is " + time);
//				((Doubler) DH.getControllers().next()).setStarttime(time);
				//((dogrotater) PowerUp.getControllers().next()).isNeeded();
				//timer2=this.time;
			}/*else if ((holder.getClass().getSuperclass()!=HUDString.class && holder.getClass()!=Line.class&& holder.getClass()!=DogHouse.class && holder.getClass()!=Square.class && holder.getClass() != Avatar.class) &&
					holder.getWorldBound().intersects(av2.getWorldBound())){      //&& !holder.equals(av2)){
				//CrashEvent newCrash = new CrashEvent(1);
				//eventMgr.triggerEvent(newCrash);
				score2++;
				CrashEvent newCrash = new CrashEvent(holder,score+score2);
				eventMgr.triggerEvent(newCrash);
				//System.out.println("the time at the crash is " + time);
				((Doubler) DH.getControllers().next()).setStarttime(time);
				((dogrotater) dogs.getControllers().next()).isNeeded();
				//timer2=this.time;
			}//*/
			//System.out.println(holder.getName());
//			if (holder.getPhysicsObject()!=null){
//				System.out.println("got here");
//				mat = new Matrix3D(holder.getPhysicsObject().getTransform());
//				translateVec = mat.getCol(3);
//				holder.getLocalTranslation().setCol(3,translateVec);
//			}
//			if (it.hasNext()){
//				holder = it.next();
//			} else holder = null;
//		}//*/
		
		it = PowerUp.iterator();
		holder=null;
		if (it.hasNext()){
			holder = it.next();
		}
		while(holder!=null){
			
			if (holder.getWorldBound().intersects(av.getWorldBound())){
				score++;
				CrashEvent newCrash = new CrashEvent(holder,10);
				 playerHealth.setArmor(10.0);
				eventMgr.triggerEvent(newCrash);
				it.remove();
			}
			if (it.hasNext()){
				holder = it.next();
			} else {
				holder=null;
				//System.out.println("got past here");
			}
			
		}
		
		it = getGameWorld().iterator();
		holder = it.next();
		while(holder!=null){
			if (holder.getPhysicsObject()!=null){
				
				//System.out.println(holder.getClass().toString());
				mat = new Matrix3D(holder.getPhysicsObject().getTransform());
				translateVec = mat.getCol(3);
				holder.getLocalTranslation().setCol(3,translateVec);
				//Matrix3D holderm = new Matrix3D();
				//holder.getLocalRotation().setElementAt(1, 1, mat.elementAt(1, 1));
				//holder.getLocalRotation().setElementAt(1, 2, mat.elementAt(1, 2));
				//holder.getLocalRotation().setElementAt(2, 1, mat.elementAt(2, 1));
				//holder.getLocalRotation().setElementAt(2, 2, mat.elementAt(2, 2));
				
				InputEvent t;
				if (holder.getClass().toString().equals("class sage.terrain.TerrainBlock")){
					mat = new Matrix3D(holder.getPhysicsObject().getTransform());
					translateVec = mat.getCol(3);
					translateVec.setY(-translateVec.getY());
					//System.out.println(translateVec.toString());
					holder.getLocalTranslation().setCol(3,translateVec);
					
				}
			}
			if (it.hasNext()){
				holder = it.next();
			} else holder = null;
		}
		
		 it = npcGroup.iterator();
		 if(it.hasNext()){
			 holder = it.next();

			 while(holder!=null){
				 if (holder!=null){
					 //System.out.println(holder.getClass().toString());
					 mat = holder.getLocalTranslation();
					 translateVec = mat.getCol(3);
					 /* System.out.println("Translet Vec: "+translateVec.getX());
					 System.out.println("Translet Vec: "+translateVec.getY());
					 System.out.println("Translet Vec: "+translateVec.getZ());
					  */
					 holder.getLocalTranslation().setCol(3,translateVec);

					 InputEvent t;
					 Vector3D avatarLoc = av.getLocalTranslation().getCol(3);
					 Vector3D npcLoc = holder.getLocalTranslation().getCol(3);

					 /*	 System.out.println("Avatar Location X : "+avatarLoc.getX());
					 System.out.println("NPC Location X : "+npcLoc.getX());
					  */	 
					 double distance = checkDistance(avatarLoc, npcLoc);
					 // System.out.println("Distance: "+distance);
					 if(playerLife()){
						 if(distance<40){
							 if (gunfiring ==false){
								 gunfiring = true;
								 //laksdkl;jg;
								 timersound=time;
								 getNpcSound().setLocation(new Point3D(holder.getWorldTranslation().getCol(3)));
								 getNpcSound().play();
							 }
							 //System.out.println("BAMMMMMMMMMM.............................................................");
							 playerHealth.PlayerHealthUpdate(elapsedTimeMS,myClient);
						 } else {
							 //gunfiring=false;
						 }
					 }
				 }
				 if (it.hasNext()){
					 holder = it.next();
				 } else holder = null;
			 }
		 }
		 System.out.println(time+ "  timersound is " + timersound);
		 if (gunfiring &&(timersound+1000)<(time)){
			 System.out.println("sound needs to stop");
			 getNpcSound().stop();
			 gunfiring=false;
		 }
		//gunfiring=false;
		 shield.setText("Shield = " + (int)playerHealth.currentShield);
		 armor.setText("Armor = " + (int)playerHealth.currentArmor);
		 time += elapsedTimeMS;
		 DecimalFormat df = new DecimalFormat("0.0");
		 mt.setText("Time = " + df.format(time/1000));
		 //"Time = " + df.format(time/1000));
		
		if ((timer2+1000)<time){
			//DH.returnToNormal();
			this.executeScript(jsEngine,scriptFileName);
			rootnode = (TriMesh) jsEngine.get("powerup");
			if (rootnode!=null){
				PowerUp.addChild(rootnode);
				//addGameWorldObject(rootnode);
				//System.out.println("rootnode is not null"); put
				
			}
			timer2=time;
		}
		it = av.getChildren();
		while(it.hasNext()){
			Model3DTriMesh submesh = (Model3DTriMesh) it.next();
			submesh.updateAnimation(elapsedTimeMS);

		}//*/
		 
		setEarParameters();
		if (myClient!=null){
		myClient.processPackets();
		}
		if (playerHealth.currentShield<100){
			playerHealth.currentShield+= .0005*elapsedTimeMS;
			if (playerHealth.currentShield>100){
				playerHealth.currentShield=100;
			}
		}
		if(!playerHealth.life){
			shutdown();
		}
	}
	
	protected void render(){
		renderer.setCamera(camera);
		super.render();
		//renderer.setCamera(camera2);
		//super.render();
	}
	
	
	private void listComponents(Controller contr){
		/*
		 * This section contains code supplied by Dr Gordon
		 */
		System.out.println ("Name: '" + contr.getName()
			+ "'. Type ID:" + contr.getType());
	// get the components in the controller, and list their details
		Component [] comps = contr.getComponents();
		for (int i=0; i < comps.length; i++)
			System.out.println (" name: " + comps[i].getName()
					+ " ID: " + comps[i].getIdentifier() );
	// find subcontrollers, if any, and recursively list their details too
			Controller[] subCtrls = contr.getControllers();
		for (int j=0; j < subCtrls.length; j++){
			System.out.println(" " + contr.getName() + " subcontroller #" + j);
			listComponents(subCtrls[j]);
		}
	}
	
	public void initClient(){
		try {
			System.out.println(InetAddress.getByName(serverAddress)+ " " + sPort);
			myClient = new MyClient(InetAddress.getByName(serverAddress),sPort, protocolType, this);
			myClient.sendJoinMessage();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ghostAvatars = new ArrayList<GhostAvatar>();
		
	}
	
	private IDisplaySystem createDisplaySystem(){
		System.out.println("In Display System");
		
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice devices = graphicsEnvironment.getDefaultScreenDevice();
		System.out.println("Devices: "+devices.getIDstring());
		DisplaySettingsDialog displaySettingsDialog = new DisplaySettingsDialog(devices);
		displaySettingsDialog.showIt();
		
		isFullScreenMode = displaySettingsDialog.isFullScreenModeSelected();
		
		display = new MyDisplay(frameWidth, frameHeight, 32, 50, isFullScreenMode, "sage.renderer.jogl.JOGLRenderer", this, myClient);
		int count = 0;

		while(!display.isCreated())
		{
			try
			{
				Thread.sleep(10);
			}
			catch (InterruptedException e)
			{
				throw new RuntimeException("Display creation interrupted");
			}
			count++;

			if(count%80==0)
			{

			}if(count>2000)
			{
				throw new RuntimeException("Unable to create display");
			}
		}


		return display;

	}
	
	public void createGhostAvatar(UUID ghostID, String[] pos)
	{
		ghostAvatarGroup = new Group();
		GhostAvatar ghostAvatar = new GhostAvatar(ghostID, pos,display,time);
		ghostAvatars.add(ghostAvatar);
		//addGameWorldObject(ghostAvatar.returnGhost());
		//addGameWorldObject(ghostAvatar.returnGhostCamera());
		//ghostAvatarGroup.addChild(ghostAvatar.returnGhost());
		//addGameWorldObject(ghostAvatarGroup);
		addGameWorldObject(ghostAvatar.returnGhost());
	}
	
	public Vector3D getPlayerPosition()
	{
		return av.getLocalTranslation().getCol(3);
	}
	
	public void updateGhost(UUID ghostID, String[] pos)
	{
		System.out.println("Ghost updating");
		while(true)
		{
			/*	System.out.println("Ghost ID of updating Ghost: "+ghostID.toString());
			System.out.println("Group Size: "+ghostAvatarGroup.getNumberOfChildren());
			 */	SceneNode temp;


			 for(int i = 0; i< ghostAvatars.size();i++ )
			 {
				 //		System.out.println("In Loop");
				 boolean thisGhost = ghostAvatars.get(i).returnID().equals(ghostID);
				 //System.out.println(ghostAvatars.get(i).retur);
				 //	System.out.println("This Ghost: "+thisGhost);
				 if(thisGhost)
				 {
					 System.out.println("Yes this is the ghost..!!!");
					 ghostAvatars.get(i).moveGhost(pos);
					 break;
				 }

			 }
			 break;
		}
	}
	
	public void removeGhost(UUID ghostID)
	{
		for(int i = 0; i<ghostAvatars.size(); i++)
		{
			boolean thisGhost = ghostAvatars.get(i).returnID().equals(ghostID);
			
			if(thisGhost)
			{
				removeGameWorldObject(ghostAvatars.get(i).returnGhost());
			//	removeGameWorldObject(ghostAvatars.get(i).returnGhostCamera());
				ghostAvatars.remove(i);
			
			}
		}
	}
	
	/*NPC*/
	public void createNPC()
	{
		Matrix3D npcLoc =new Matrix3D();
		Vector3D vNpcLoc = new Vector3D();

		for(int i=0;i<15;i++){
			npc = new NPC(display,time);
			//addGameWorldObject(npc.returnNPC());

			npcGroup.addChild(npc.returnNPC());
			//adsgasfd;
			/*npc.updateLocalBound();
			npc.updateWorldBound();
			 */
			//npcLoc = npc.getWorldTransform();
			//npcLoc = npc.getWorldTranslation();
			//npc.gun.updateGeometricState(time, true);
			//System.out.println("NPC Location: "+npc.gun.getLocalTranslation());
		}	
		addGameWorldObject(npcGroup);
	}
	/**/
	public Vector3D npcPosition(){
		return npc.getLocalTranslation().getCol(3);
	}
	
	public double checkDistance(Vector3D avLoc,Vector3D npcLoc){

		return Math.sqrt(Math.pow(avLoc.getX()-npcLoc.getX(), 2.0)+
				Math.pow(avLoc.getY()-npcLoc.getY(), 2.0)+
				Math.pow(avLoc.getZ()-npcLoc.getZ(), 2.0));

	}
	
	public boolean playerLife(){
		return playerHealth.life;
	}
	
	public void shutdown()
	{
		
		
		if(myClient!=null)
		{
			//setIsConnected(false);
			myClient.sendByeMessage();
			try {
				//wait(15);
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try
		{
			if (myClient!=null){
			myClient.shutdown();
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		//getNpcSound().release(getAudioMgr());
		//waterSound.release(audioMgr);
		// Next release audio resources
		//getResource1().unload();
		//resource2.unload();
		// Finally shut down the audio manager
		//getAudioMgr().shutdown();
		getNpcSound().release(getAudioMgr());
		//waterSound.release(audioMgr);
		// Next release audio resources
		getResource1().unload();
		//resource2.unload();
		// Finally shut down the audio manager
		if (getAudioMgr().initialize()){
		getAudioMgr().shutdown();
		}
		super.shutdown();
	}
	public void setIsConnected(Boolean b)
	{
		isConnected = b;
	}

	public boolean isConnected()
	{
		return isConnected;
	}

	public Sound getNpcSound() {
		return npcSound;
	}

	public void setNpcSound(Sound npcSound) {
		this.npcSound = npcSound;
	}

	public AudioResource getResource1() {
		return resource1;
	}

	public void setResource1(AudioResource resource1) {
		this.resource1 = resource1;
	}

	public IAudioManager getAudioMgr() {
		return audioMgr;
	}

	public void setAudioMgr(IAudioManager audioMgr) {
		this.audioMgr = audioMgr;
	}
	
	public void quitGame()
	{


		System.out.println("War (Working Title) Shutdown.");
		this.setGameOver(true);
		System.exit(0);

	}
}
