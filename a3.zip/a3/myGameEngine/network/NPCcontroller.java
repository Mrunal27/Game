package myGameEngine.network;

import java.util.Random;
import java.util.UUID;

import graphicslib3D.Matrix3D;
import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import myGameEngine.MyGame;
import sage.display.IDisplaySystem;
import sage.model.loader.OBJLoader;
import sage.scene.state.TextureState;
import sage.scene.TriMesh;
import sage.scene.state.RenderState.RenderStateType;
import sage.texture.Texture;
import sage.texture.TextureManager;

public class NPCcontroller extends TriMesh{

	private UUID npcID;
	private Point3D npcLoc;
	NPC npc;
	
	public NPCcontroller() {
		// TODO Auto-generated constructor stub
		super();     
		
		
	}
	public void setUpNPC(){
		System.out.println("Create NPC");
	}

	public void createNPC(IDisplaySystem display,float time){
		npc = new NPC(display, time);
	}
	
	public TriMesh returnGhost(){
		return npc;
	}
}
