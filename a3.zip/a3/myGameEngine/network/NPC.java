package myGameEngine.network;

import java.util.Random;
import java.util.UUID;

import graphicslib3D.Matrix3D;
import graphicslib3D.Point3D;
import sage.display.IDisplaySystem;
import sage.model.loader.OBJLoader;
import sage.scene.TriMesh;
import sage.scene.state.TextureState;
import sage.scene.state.RenderState.RenderStateType;
import sage.texture.Texture;
import sage.texture.TextureManager;

public class NPC extends TriMesh{
	
	private UUID npcID;
	private Point3D npcLoc;
	public TriMesh gun;

	public NPC(IDisplaySystem display,float time){
		System.out.println("Here in NPC For Including and texturing");
		//this.npcID = npcID;
		//npcLoc = new Point3D(Float.valueOf(pos[0]), Float.valueOf(pos[1]),Float.valueOf(pos[2]));
		OBJLoader loader = new OBJLoader();
		gun=new TriMesh();
		gun = loader.loadModel("gun.obj");
		Matrix3D gm = gun.getLocalScale();
		gm.scale(.1, .1, .1);
		gun.setLocalScale(gm);
		TextureState gunTS;
		Texture gunT = TextureManager.loadTexture2D("CamoColor.jpg");
		gunT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
		gunTS = (TextureState) display.getRenderer().createRenderState(RenderStateType.Texture);
		gunTS.setTexture(gunT, 0);
		gunTS.setEnabled(true);
		gun.setRenderState(gunTS);

		//av = new Avatar(display);
		Matrix3D gunM = gun.getLocalTranslation();
		Random rng = new Random();
		//gunM.translate(1, .5, 20);
		gunM.translate(rng.nextDouble()*400, .5, rng.nextDouble()*400);
		gun.setLocalTranslation(gunM);
		gun.updateWorldBound();
		gun.updateLocalBound();
	}
	
	public TriMesh returnNPC(){
		return gun;
	}
}
