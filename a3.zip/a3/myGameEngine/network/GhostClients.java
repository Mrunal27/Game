package myGameEngine.network;

import java.util.UUID;

import sage.scene.TriMesh;

public class GhostClients extends TriMesh{
	UUID id;
	
	public GhostClients(){
		super();
		
	}
	
	public GhostClients(UUID uuid){
		this.id = uuid;
	}
}
