package myGameEngine.network;

import java.io.IOException;
import java.sql.Time;

import sage.networking.IGameConnection.ProtocolType;

public class TestNetworkingServer {
	
	long startTime;
	long lastUpdateTime;
	
	public TestNetworkingServer(int id) {
		// TODO Auto-generated constructor stub
		//System.out.println("hello from the server");
		startTime = System.nanoTime();
		lastUpdateTime = startTime;
	
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//GameServerTCP testTCPServer;
		//System.out.println("hello from the server");
		try {
			GameServerTCP testTCPServer = new GameServerTCP(6000,ProtocolType.TCP);  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
	}

}
