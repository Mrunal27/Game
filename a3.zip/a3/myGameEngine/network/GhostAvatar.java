package myGameEngine.network;

import java.awt.Color;
import java.util.Random;
import java.util.UUID;

import com.jogamp.nativewindow.util.Point;

import graphicslib3D.Matrix3D;
import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import sage.display.IDisplaySystem;
import sage.model.loader.OBJLoader;
import sage.scene.TriMesh;
import sage.scene.shape.Sphere;
import sage.scene.state.TextureState;
import sage.scene.state.RenderState.RenderStateType;
import sage.texture.Texture;
import sage.texture.TextureManager;

public class GhostAvatar extends TriMesh{
	
	private UUID ghostID;
	private MySphere ghost;
	private Point3D ghostLoc;
	TriMesh av;
		
	public GhostAvatar(UUID ghostID,String[] pos,IDisplaySystem display,float time) {
		// TODO Auto-generated constructor stub
		
		 	this.ghostID = ghostID;
		 	ghostLoc = new Point3D(Float.valueOf(pos[0]), Float.valueOf(pos[1]),Float.valueOf(pos[2]));
            		 	
			OBJLoader loader = new OBJLoader();
			av = new GhostClients(ghostID);
			av = loader.loadModel("spider3.obj");
			Matrix3D bgm = av.getLocalScale();
			bgm.scale(.1, .1, .1);
			av.setLocalScale(bgm);
			Matrix3D bgrm = av.getLocalRotation(); 
			bgrm.rotate(-90, new Vector3D(0.0,1.0,0.0));
			av.setLocalRotation(bgrm);
			TextureState spiderTS;
			Texture spiderT = TextureManager.loadTexture2D("spider2.png");
			spiderT.setApplyMode(sage.texture.Texture.ApplyMode.Replace);
			spiderTS = (TextureState) display.getRenderer().createRenderState(RenderStateType.Texture);
			spiderTS.setTexture(spiderT, 0);
			spiderTS.setEnabled(true);
			av.setRenderState(spiderTS);

			Matrix3D avM = av.getLocalTranslation();
			Random rng = new Random();
			//avM.translate(1, 0.5, 10);
			avM.translate(Float.valueOf(pos[0]), Float.valueOf(pos[1]),Float.valueOf(pos[2]));
			av.setLocalTranslation(avM);
			//av.updateWorldBound();
			av.updateLocalBound();
			av.updateWorldBound();
			av.updateGeometricState(time, true);
			double[] a = av.getLocalTranslation().getValues();
	}

	public TriMesh returnGhost(){
		return av;
	}
	
	public Point3D returnGhostLocation(){
		return ghostLoc;
	}

	public UUID returnID(){
		return ghostID;
	}
	
	public void moveGhost(String[] pos)
	{
		/*System.out.println("pos[0] : "+Float.valueOf(pos[0]));
		System.out.println("pos[1] : "+Float.valueOf(pos[1]));
		System.out.println("pos[2] : "+Float.valueOf(pos[2]));
		*/
		ghostLoc = new Point3D(Float.valueOf(pos[0]), Float.valueOf(pos[1]),Float.valueOf(pos[2]));
		Matrix3D translation = new Matrix3D();
		translation.translate(Float.valueOf(pos[0]), ((Float.valueOf(pos[1]))), Float.valueOf(pos[2]));
		av.setLocalTranslation(translation);
	}
}
