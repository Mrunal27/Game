package myGameEngine.network;

import java.awt.Color;
import java.util.UUID;

import sage.scene.shape.Sphere;

public class MySphere extends Sphere{

	UUID id;
	
	public MySphere(){
		super(1,15,14,Color.RED);
		this.setColor(Color.MAGENTA);
	}
	
	public MySphere(UUID id) {
		// TODO Auto-generated constructor stub
		this.id = id;
		
	}

}
