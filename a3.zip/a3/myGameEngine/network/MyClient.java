package myGameEngine.network;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.UUID;
import java.util.Vector;

import graphicslib3D.Vector3D;
import myGameEngine.MyGame;
import sage.networking.client.GameConnectionClient;

public class MyClient extends GameConnectionClient{

	private MyGame game;
	private UUID id;
	private ArrayList<UUID> ghostPlayers;
	boolean added = true;
	

	public MyClient(InetAddress remoteAddr, int remotePort,	ProtocolType protocolType, MyGame myGame) throws IOException {
		super(remoteAddr, remotePort, protocolType);
		// TODO Auto-generated constructor stub
		this.game = myGame;
		id = UUID.randomUUID();
		ghostPlayers = new ArrayList<UUID>();
	}

	protected void processPacket(Object msg){
		String message = (String)msg;
		String msgTokens[] = message.split(",");
	//	System.out.println("Message in process packet:"+message);

		if(msgTokens[0].compareTo("join")==0){
			if (msgTokens[1].compareTo("success") == 0) {

				if (game.isConnected() == false) {
					game.setIsConnected(true);
					
					System.out.println("\nJoined the Game Successfully.\n");
					createNPC();
					added=false;
				}
				
				
			}
			if (msgTokens[1].compareTo("failure") == 0) {
				game.setIsConnected(false);
				System.out.println("Could Not Join the Game.\n");
			} 
			
			sendCreateMessage(game.getPlayerPosition());
			
		}
		if(msgTokens[0].compareTo("bye")==0)
		{
			UUID ghostID = UUID.fromString(msgTokens[1]);
			removeGhostAvatar(ghostID);
		}
		if(msgTokens[0].compareTo("create")==0){
			System.out.println("Creating Ghost Avatar\n");

			UUID ghostID = null;
			try{
				ghostID = UUID.fromString(msgTokens[1]);
			}catch(NumberFormatException e){
				e.printStackTrace();
			}
			System.out.println("Ghost ID: "+ghostID.toString());
			String[] pos = {msgTokens[2], msgTokens[3], msgTokens[4]};

			if(ghostID!=id)
			{
				boolean addMe = true;

				for(int i = 0; i<ghostPlayers.size(); i++)
				{
					boolean thisGhost = ghostPlayers.get(i).equals(ghostID);

					if(thisGhost)
					{
						addMe = false;
					}

				}

				if(addMe)
				{
					createGhostAvatar(ghostID, pos);	
					ghostPlayers.add(ghostID);
				}
			}

		}

		if(msgTokens[0].compareTo("newcomer")==0)
		{
			sendCreateMessage(game.getPlayerPosition());
		}

		if(msgTokens[0].compareTo("move")==0){
			System.out.println("In Client: move received");

			UUID ghostID = UUID.fromString(msgTokens[1]);

			String[] pos = {msgTokens[2], msgTokens[3], msgTokens[4]};
			/*	String[] cameraPos = {msgTokens[5], msgTokens[6], msgTokens[7]};
			String[] cameraRot1 = {msgTokens[8], msgTokens[9], msgTokens[10]};
			String[] cameraRot2 = {msgTokens[11], msgTokens[12], msgTokens[13]};
			 */
			if(ghostID!=id)
			{
				System.out.println("In client ID not same");
				game.updateGhost(ghostID, pos);//, cameraPos, cameraRot1, cameraRot2);
			}
		}

		if(msgTokens[0].compareTo("npc")==0){
			/*	UUID npcID = UUID.fromString(msgTokens[1]);*/
			//		String pos[]={msgTokens[2],msgTokens[3],msgTokens[4]};

			/*if(added){
				createNPC();
				added=false;
			}*/

		}
		if(msgTokens[0].compareTo("health")==0){
			System.out.println("Just Here");
			//sendPlayerHealth(shield, armor);
		}
	}

	private void createGhostAvatar(UUID ghostID, String[] pos) {
		// TODO Auto-generated method stub
		game.createGhostAvatar(ghostID, pos);
	}
	private void removeGhostAvatar(UUID ghostID) {
		game.removeGhost(ghostID);
	}
	private void createNPC(){
		game.createNPC();
	}
	public void sendPlayerHealth(double shield,double armor,boolean life){
		String message=null;
		try{
			if(life){
				message = new String("health,"+ id.toString());
				message+=","+shield+","+armor;
				//System.out.println("Health of Player: "+message.toString());
			}else{
				message = new String("health,"+ id.toString());
				message+=","+"player"+","+"dead";
				//System.out.println("Health of Player dead: "+message.toString());
			}

			sendPacket(message);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public void sendCreateMessage(Vector3D pos){ 
		// format: (create, localId, x,y,z)
		try {
			String message = new String("create," + id.toString());
			message += "," + pos.getX() + "," + pos.getY() + "," + pos.getZ();
			sendPacket(message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void sendJoinMessage(){ 
		// format: join, localId
		System.out.println("need to join");
		try{ 
			sendPacket(new String("join," + id.toString()));
		}catch (IOException e) { 
			e.printStackTrace(); 
		}
	}

	public void sendByeMessage()
	{  
		try {
			//	System.out.println("Received Bye Message");
			sendPacket(new String("bye," + id.toString()));
			this.shutdown();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void sendDetailsForMessage(UUID remId, Vector3D pos)
	{ 
		//	System.out.println("Send Details For Message");
		try{ 
			sendPacket(new String("Send," + remId.toString())); 
		}catch (IOException e) { 
			e.printStackTrace(); 
		}
	}
	public void sendMoveMessage(Vector3D pos)
	{ 
		try {
			//	System.out.println("Willl Send Move Message to server");
			String message = new String("move," + id.toString());
			message += "," + pos.getX() + "," + pos.getY() + "," + pos.getZ();
			/*		System.out.println("getX():"+pos.getX());
			System.out.println("getY():"+pos.getY());
			System.out.println("getZ():"+pos.getZ());
			 */		
			sendPacket(message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	public void sendNPCMessage() {
		try {
			String message = new String("npc," + id.toString());
			//			message += "," + pos.getX() + "," + pos.getY() + "," + pos.getZ();
			sendPacket(message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}


