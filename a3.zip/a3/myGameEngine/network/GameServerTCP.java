package myGameEngine.network;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.UUID;

import myGameEngine.MyGame;
import sage.networking.server.GameConnectionServer;
import sage.networking.server.IClientInfo;
import sage.networking.server.UDPClientInfo;
import sage.networking.server.UDPServerSocket;

public class GameServerTCP extends GameConnectionServer<UUID>{

	private ArrayList<UUID> clients = new ArrayList<UUID>();

	public GameServerTCP(int localPort, ProtocolType protocolType) throws IOException {
		// TODO Auto-generated constructor stub
		super(localPort, protocolType);
	}


	public void acceptClient(IClientInfo ci,Object o){
		String message = (String)o;
		String messageTokens[] = message.split(",");

		if(messageTokens.length > 0){
			if(messageTokens[0].compareTo("join") == 0){

				UUID clientID = UUID.fromString(messageTokens[1]);
				boolean addClient = true;
				for(int i =0; i<clients.size();i++)
				{
					if(clientID==clients.get(i))
					{
						addClient = false;
					}
					else
					{

					}
				}
				if(addClient)
				{
					clients.add(clientID);
					addClient(ci, clientID);
					sendJoinedMessage(clientID,true);
					//sendNPCMessage(clientID);
					
					
				}

			}
		}
	}

	public void processPacket(Object o,InetAddress senderIP,int sndPort){

		super.processPacket(o, senderIP,  sndPort);
		if(o!=null){
			String message = (String)o;

			if(message!=null){
				String[] msgTokens = message.split(",");

				if(msgTokens.length > 0){
					UUID clientID = UUID.fromString(msgTokens[1]);
					if(msgTokens[0].compareTo("bye")==0){
						System.out.println("Bye Received");
						sendByeMessage(clientID);
						removeClient(clientID);
						
						while(true)
						{
							for(int i = 0; i<clients.size(); i++)
							{
								boolean thisClient = clients.get(i).equals(clientID);

								if(thisClient)
								{
									clients.remove(i);
									System.out.println("\nServer: A Player Has Disconnected From the Session.");								
									break;
								}
							}
							break;
						}
						if(clients.size()==0)
						{

							System.out.println("\nAll clients have closed their connections. The server is going to shutdown...");
							try {
								this.shutdown();
								System.out.println("...Server Shutdown Succesffully.");
								System.exit(0);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						else
						{
							System.out.println("There are still " + clients.size() + " clients connected to the session.");

						}

					}
					

					
					if(msgTokens[0].compareTo("create")==0){

						String[] pos = {msgTokens[2], msgTokens[3], msgTokens[4]};
						/*String[] cameraPos = {msgTokens[5], msgTokens[6], msgTokens[7]};
						String[] cameraRot1 = {msgTokens[8], msgTokens[9], msgTokens[10]};
						String[] cameraRot2 = {msgTokens[11], msgTokens[12], msgTokens[13]};
						 */
						
						sendCreateMessage(clientID, pos);

					}

					if(msgTokens[0].compareTo("npc")==0){
						String[] pos = {msgTokens[2],msgTokens[3],msgTokens[4]};
						sendNPCMessage(clientID,pos);
					}
					if(msgTokens[0].compareTo("dsfr")==0){

					}

					if(msgTokens[0].compareTo("move")==0){
						String[] pos = {msgTokens[2], msgTokens[3], msgTokens[4]};
					/*	String[] cameraPos = {msgTokens[5], msgTokens[6], msgTokens[7]};
						String[] cameraRot1 = {msgTokens[8], msgTokens[9], msgTokens[10]};
						String[] cameraRot2 = {msgTokens[11], msgTokens[12], msgTokens[13]};
					 */
				/*		System.out.println("In Server Received Move");
						System.out.println("pos[0]"+pos[0]);
						System.out.println("pos[1]"+pos[1]);
						System.out.println("pos[2]"+pos[2]);
				*/		
						sendMoveMessage(clientID, pos);
					}


					if(msgTokens[0].compareTo("")==0){
						//			UUID clientID = UUID.fromString(msgTokens[1]);

					}
					
					if(msgTokens[0].compareTo("health") ==0){
						String[] health = {msgTokens[1],msgTokens[2]};
						sendHealthMessage(clientID, health);
					}

				}
			}
		}
	}

	public void sendJoinedMessage(UUID clientID,boolean success){
		//System.out.println("yea someone wants to join");
		try{
			String message = new String("join,");
			if(success) 
			{
				message += "success";
				sendPacket(message,clientID);

				System.out.println("\nServer: A New Client Has Joined the Session as Player " + clients.size() + ".\nClientID: " + clientID);
		
				String notifyJoin = new String("newcomer");
				forwardPacketToAll(notifyJoin, clientID);
			}
			else{
				message += "failure";
				System.out.println("failure");
			}
			sendPacket(message,clientID);
		}catch(IOException e) {e.printStackTrace();}
	}

	public void sendCreateMessage(UUID clientID,String[] position){
		try{
			String message = new String("create,"+clientID.toString());
			message+=","+position[0];
			message+=","+position[1];
			message+=","+position[2];
			forwardPacketToAll(message,clientID);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void sendNPCMessage(UUID clientID,String[] position){
		try{
			String message = new String("npc,"+clientID.toString());
			
			message+=","+position[0];
			message+=","+position[1];
			message+=","+position[2];
			forwardPacketToAll(message,clientID);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void sendHealthMessage(UUID clientID,String[] health){
		try{
			String message = new String("health,"+clientID.toString());
			message+=","+health[0];
			message+=","+health[1];
			forwardPacketToAll(message, clientID);
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public void sendDetailsMsg(UUID clientID,UUID remoteID,String[] position){
		try{
			String message = new String("Send Details Message"+clientID.toString());
			message+= new String(remoteID.toString());
			message+=","+position[0];
			message+=","+position[0];
			message+=","+position[0];

			forwardPacketToAll(message, remoteID);
		}catch(Exception c){

		}
	}
	public void sendWantsDetailsMsg(UUID clientID){
		String message = new String("Send Wants Details"+clientID.toString());
		try {
			sendPacket(message, clientID);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void sendMoveMessage(UUID clientID,String[] pos){
		System.out.println("In server Sending Move Message to all clients");
		try{
			String message = new String("move," + clientID);
			message += "," + pos[0];
			message += "," + pos[1];
			message += "," + pos[2];
			forwardPacketToAll(message, clientID);
		}catch(IOException e){e.printStackTrace();}


	}
	public void sendByeMessage(UUID clientID){
		String message = new String("bye,"+clientID);
		try{
			forwardPacketToAll(message, clientID);
		}catch(IOException e){
			e.printStackTrace();
		}

	}
}
