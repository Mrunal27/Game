package myGameEngine;

public class Spring {

}
