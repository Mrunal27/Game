package myGameEngine;

import sage.scene.HUDString;

public class MyTime extends HUDString {

	public MyTime(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
