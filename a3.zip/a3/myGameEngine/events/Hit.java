package myGameEngine.events;

import sage.event.AbstractGameEvent;

public class Hit extends AbstractGameEvent {

}
