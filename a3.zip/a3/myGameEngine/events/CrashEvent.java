package myGameEngine.events;

import a3.PowerUp.ArmorPowerUp;
//import a1.animals.Pyramid;
import sage.event.AbstractGameEvent;
import sage.scene.SceneNode;

public class CrashEvent extends AbstractGameEvent {
	/*
	 * This section contains code supplied by Dr Gordon
	 */
	private SceneNode trigger;
	private int number;
	 //private Pyramid whichCrash;
	 public CrashEvent(SceneNode holder, int n) { 
		 trigger = holder; number=n;}
	 public SceneNode getWhichCrash() { 
		 return trigger; }
	 public int getnumber(){
		 return number;
	 }
	 
}
