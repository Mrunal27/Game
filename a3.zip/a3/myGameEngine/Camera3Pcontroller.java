package myGameEngine;

import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import myGameEngine.commands.OrbitAroundAction;
import myGameEngine.commands.OrbitElevation;
import net.java.games.input.Component.Identifier.Axis;
import sage.camera.ICamera;
import sage.input.IInputManager;
import sage.input.action.IAction;
import sage.scene.SceneNode;
import sage.util.MathUtils;

public class Camera3Pcontroller {
	private ICamera cam; //the camera being controlled
	private SceneNode target; //the target the camera looks at
	private float cameraAzimuth; //rotation of camera around target Y axis
	private float cameraElevation; //elevation of camera above target
	private float cameraDistanceFromTarget;
	private Point3D targetPos; // avatar�s position in the world
	private Vector3D worldUpVec;
	
	public Camera3Pcontroller(ICamera cam, SceneNode target,IInputManager inputMgr, String controllerName){
		this.cam = cam;
		this.target = target;
		worldUpVec = new Vector3D(0,1,0);
		setCameraDistanceFromTarget(10.0f);
		setCameraAzimuth(180); // start from BEHIND and ABOVE the target
		setCameraElevation(20.0f); // elevation is in degrees
		update(0.0f); // initialize camera state
		//setupInput(inputMgr, controllerName);
	}
	public void update(float time){
		if (target==null){
			System.out.println("target is null");
		}
		updateTarget();
		updateCameraPosition();
		Point3D tar = targetPos;
		tar.setY(tar.getY()+.5);
		cam.lookAt(tar, worldUpVec); // SAGE built-in function
	}
	private void updateTarget(){
		targetPos = new Point3D(target.getWorldTranslation().getCol(3)); }
	
	private void updateCameraPosition(){
		double theta = getCameraAzimuth();
		double phi = getCameraElevation() ;
		double r = getCameraDistanceFromTarget();
		// calculate new camera position in Cartesian coords
		Point3D relativePosition = MathUtils.sphericalToCartesian(theta, phi, r);
		Point3D desiredCameraLoc = relativePosition.add(targetPos);
		cam.setLocation(desiredCameraLoc);
	}
	private void setupInput(IInputManager im, String cn)
	{ 
		//IAction orbitAction = new OrbitAroundAction(this);
		//IAction orbitEleAction = new OrbitElevation(this);

//		im.associateAction(cn, net.java.games.input.Component.Identifier.Axis.RX, orbitAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
//		im.associateAction(cn, net.java.games.input.Component.Identifier.Axis.RY, orbitEleAction, IInputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
	
	}
	public float getCameraAzimuth() {
		return cameraAzimuth;
	}
	public void setCameraAzimuth(float cameraAzimuth) {
		this.cameraAzimuth = cameraAzimuth;
	}
	public float getCameraElevation() {
		return cameraElevation;
	}
	public void setCameraElevation(float cameraElevation) {
		this.cameraElevation = cameraElevation;
	}
	public float getCameraDistanceFromTarget() {
		return cameraDistanceFromTarget;
	}
	public void setCameraDistanceFromTarget(float cameraDistanceFromTarget) {
		this.cameraDistanceFromTarget = cameraDistanceFromTarget;
	}
}
