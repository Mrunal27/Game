package myGameEngine.commands;

import myGameEngine.MyGame;
import net.java.games.input.Event;
import sage.input.action.AbstractInputAction;

public class Exit extends AbstractInputAction {
	private MyGame g;
	public Exit(MyGame game){
		g=game;
	}
	
	@Override
	public void performAction(float arg0, Event arg1) {
		// TODO Auto-generated method stub
		g.getNpcSound().release(g.getAudioMgr());
		//waterSound.release(audioMgr);
		// Next release audio resources
		g.getResource1().unload();
		//resource2.unload();
		// Finally shut down the audio manager
		g.getAudioMgr().shutdown();
		g.setGameOver(true);
		
	}

}
