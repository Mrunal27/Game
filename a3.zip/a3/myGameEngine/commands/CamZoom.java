package myGameEngine.commands;

import myGameEngine.Camera3Pcontroller;
import net.java.games.input.Event;
import sage.input.action.AbstractInputAction;

public class CamZoom extends AbstractInputAction {
	private Camera3Pcontroller cam;
	
	
	public CamZoom(Camera3Pcontroller cam){
		this.cam=cam;
	}
	@Override
	public void performAction(float arg0, Event evt) {
		// TODO Auto-generated method stub
		
		//System.out.println(evt.getComponent());
		
		if (evt.getValue()<-.3|| evt.getComponent().getName().equals("Q")){
			cam.setCameraDistanceFromTarget(cam.getCameraDistanceFromTarget()+.1f);
		} else if (evt.getValue()>.3|| evt.getComponent().getName().equals("E")){
			cam.setCameraDistanceFromTarget(cam.getCameraDistanceFromTarget()-.1f);
		}
	}

}
