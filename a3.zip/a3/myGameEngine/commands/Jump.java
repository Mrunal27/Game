package myGameEngine.commands;

import net.java.games.input.Event;
import sage.event.AbstractGameEvent;
import sage.input.action.AbstractInputAction;
import sage.scene.Group;
import sage.scene.TriMesh;

public class Jump extends AbstractInputAction {
	Group av;
	
	public Jump(Group av2){
		this.av=av2;
	}

	@Override
	public void performAction(float arg0, Event arg1) {
		// TODO Auto-generated method stub
		
	}
}
