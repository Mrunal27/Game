package myGameEngine.commands;

import net.java.games.input.Event;
import sage.input.action.AbstractInputAction;

public class ObitShiftRotation extends AbstractInputAction {
	private boolean active=false;
	private OrbitAroundAction o;
	
	public ObitShiftRotation(OrbitAroundAction o){
		this.o=o;
	}
	
	@Override
	public void performAction(float arg0, Event evt) {
		// TODO Auto-generated method stub
//		System.out.println(evt.getValue());
		if (evt.getValue()>.1){
			o.setShift(true);
		} else if (evt.getValue()==0){
			o.setShift(false);
		}
	}

}
