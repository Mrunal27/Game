package myGameEngine.commands;

import a3.Player.Avatar;
import graphicslib3D.Matrix3D;
import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import myGameEngine.network.MyClient;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;
import sage.physics.IPhysicsObject;
import sage.scene.Group;
import sage.scene.TriMesh;
import sage.terrain.*;


public class Forward extends AbstractInputAction {
	//camera = c;
	//runAction = r;
	private ICamera camera;
	private Group av;
	private TerrainBlock terrain;
	private MyClient client;
	
	 public Forward(Group av2, TerrainBlock ter,MyClient myClient) //, SetSpeedAction r)
	 { this.av=av2;
	 this.terrain=ter;
	 this.client = myClient;
	 //runAction = r;
	 }
	
	@Override
	public void performAction(float arg0, net.java.games.input.Event e) {
		// TODO Auto-generated method stub
		float moveAmount ;
		//if (runAction.isRunning()){
		//	moveAmount = (float) 0.5 ; 
		//}
		//else{
			moveAmount = (float) 0.005 ; 
		//}
			/*
			 * This section contains code supplied by Dr Gordon
			 */
		//av.
	//	Vector3D viewDir = av.getHeading();    //camera.getViewDirection().normalize();
		Point3D p = new Point3D(av.getLocalTranslation().getValues());
		Vector3D curLocVector = new Vector3D(p);
		Vector3D newLocVec;
		//System.out.println(e.getValue() + "foward");
		//System.out.println("hmmmm.....");
		if(e.getValue()<-0.3 || e.getComponent().getName().equals("W")){
			/*
			newLocVec = curLocVector.add(viewDir.normalize().mult(moveAmount*arg0));
			double newX = newLocVec.getX();
			double newY = newLocVec.getY();
			double newZ = newLocVec.getZ();
			Point3D newLoc = new Point3D(newX, newY, newZ);
			//Matrix3D temp = new Matrix3D(newLoc.getX(),newLoc.getY(), newLoc.getZ());
			Matrix3D rot  = av.getHeading1();
			Vector3D dir=new Vector3D(0,0,1);
			dir=dir.mult(rot);
			dir.scale(.1);
			av.translate((float)dir.getX(), (float)dir.getY(), (float)dir.getZ());
			//*/
			
			//updateVerticalPosition();
			float[] po = av.getPhysicsObject().getLinearVelocity();
			float a[] = av.getLocalRotation().getFloatValues();
			
			//System.out.println(a[1]); //0 was 0, 1 = pos might be up
			po[2]=(float) (-12*av.getLocalRotation().elementAt(0, 2));
			po[0]=(float) (12*av.getLocalRotation().elementAt(0, 0));
			//Math.sin(av.getLocalRotation().elementAt(1, 1));
			
			//IPhysicsObject b = av.getPhysicsObject();
			//av.getPhysicsObject().set
			av.getPhysicsObject().setLinearVelocity(po);
/*			System.out.println("rotation matrix");
			System.out.print(a[0]+ " ");
			System.out.print(a[1]+ " ");
			System.out.print(a[2]+ " ");
			System.out.print(a[3]+ " "); System.out.println("");
			System.out.print(a[4]+ " "); 
			System.out.print(a[5]+ " ");
			System.out.print(a[6]+ " ");
			System.out.print(a[7]+ " "); System.out.println("");
			System.out.print(a[8]+ " "); 
			System.out.print(a[9]+ " ");
			System.out.print(a[10]+ " ");
			System.out.print(a[11]+ " "); System.out.println("");
			System.out.print(a[12]+ " ");
			System.out.print(a[13]+ " ");
			System.out.print(a[14]+ " ");
			System.out.print(a[15]+ " ");
			System.out.println();
			System.out.println();
			System.out.println();//*/
//			System.out.println(Math.acos(av.getLocalRotation().elementAt(0, 0)));
			//*/
//			av.getPhysicsObject().setLinearVelocity({1.0f,0.0f,0.0f});
			
			//av.getLocalTranslation().translate(newX, newY, newZ);
			//System.out.println("i moved.  I need to send a message");
			if (client!=null){
			client.sendMoveMessage(av.getLocalTranslation().getCol(3));
			}
		}//	/*
		//else if ((e.getValue()>0.2 && e.getComponent().getName().equals("Y Axis"))  || e.getComponent().getName().equals("S")&e.getValue()==1.0){
		//	newLocVec = curLocVector.minus(viewDir.mult(moveAmount*arg0));
		else if (e.getValue()>0.3  || e.getComponent().getName().equals("S")){
			//newLocVec = curLocVector.minus(viewDir.normalize().mult(moveAmount*arg0));
			//double newX = newLocVec.getX();
			//double newY = newLocVec.getY();
			//double newZ = newLocVec.getZ();
			//Point3D newLoc = new Point3D(newX, newY, newZ);
			//av.getLocalTranslation().translate(newX, newY, newZ);
			/*
			Matrix3D rot  = av.getHeading1();
			Vector3D dir=new Vector3D(0,0,-1);
			dir=dir.mult(rot);
			dir.scale(.1);
			av.translate((float)dir.getX(), (float)dir.getY(), (float)dir.getZ());
			//*/
			
			float[] po = av.getPhysicsObject().getLinearVelocity();
			float a[] = av.getLocalRotation().getFloatValues();
			
			//System.out.println(a[1]); //0 was 0, 1 = pos might be up
			po[2]=(float) (12*av.getLocalRotation().elementAt(0, 2));
			po[0]=(float) (-12*av.getLocalRotation().elementAt(0, 0));
			//Math.sin(av.getLocalRotation().elementAt(1, 1));
			
			//IPhysicsObject b = av.getPhysicsObject();
			//av.getPhysicsObject().set
			av.getPhysicsObject().setLinearVelocity(po);
			if(client!=null){
			client.sendMoveMessage(av.getLocalTranslation().getCol(3));
			}
			//updateVerticalPosition();
//			av.setLocalTranslation(av.getLocalTranslation().translate(newX, newY, newZ));
		}
		else if (e.getValue()>-.1&&e.getValue()<.1){
			//float[] a = av.getPhysicsObject().getLinearVelocity();
			//System.out.println("forward worked "+a[1]); //0 was 0, 1 = pos might be up
			//a[2]=0.0f;
			//IPhysicsObject b = av.getPhysicsObject();
			
			//av.getPhysicsObject().setLinearVelocity(a);
//			
		}
		//System.out.println(e.getValue());
		//updateVerticalPosition();
	}
	
	private void updateVerticalPosition(){
		Point3D avLoc = new Point3D(av.getLocalTranslation().getCol(3));
		float x = (float) avLoc.getX();
		float z = (float) avLoc.getZ();
		//if (terrain==null){System.out.println("terHeight is null");}
		//System.out.println(x + " "+ z);
		
		//System.out.println(terrain.getSize());
		float terHeight = terrain.getHeight(x,z);
		float desiredHeight = terHeight + (float)terrain.getOrigin().getY() + 1.5f;
		av.getLocalTranslation().setElementAt(1, 3, desiredHeight);
	}

}
