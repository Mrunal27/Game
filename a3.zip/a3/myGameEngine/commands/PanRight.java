package myGameEngine.commands;

import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;

public class PanRight extends AbstractInputAction {
	private ICamera camera;
	
	public PanRight(ICamera c){
		camera = c;
	}
	@Override
	public void performAction(float arg0, net.java.games.input.Event e) {
		// TODO Auto-generated method stub
		Float moveAmount;
		moveAmount= (float) 0.005;
		
		/*
		 * This section contains code supplied by Dr Gordon
		 */
		Vector3D viewDir = camera.getRightAxis().normalize(); // .getViewDirection().normalize();
		Vector3D curLocVector = new Vector3D(camera.getLocation());
		Vector3D newLocVec;
		//if(e.getValue()<-0.2 || e.getComponent().getName().equals("A")){
		//	newLocVec = curLocVector.minus(viewDir.mult(moveAmount*arg0));
		//}
		//else if (e.getValue()>0.2 && e.getComponent().getName().equals("X Axis") || e.getComponent().getName().equals("D")){
			newLocVec = curLocVector.add(viewDir.mult(moveAmount*arg0));
		//} else{
		//	newLocVec = curLocVector;
		//}
		//System.out.println(e.getComponent().getName());
		double newX = newLocVec.getX();
		double newY = newLocVec.getY();
		double newZ = newLocVec.getZ();
		Point3D newLoc = new Point3D(newX, newY, newZ);
		camera.setLocation(newLoc);
	}

}
