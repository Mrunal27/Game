package myGameEngine.commands;

import graphicslib3D.Matrix3D;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;

public class PitchUp extends AbstractInputAction {
	private ICamera camera;
	
	public PitchUp(ICamera c){
		camera = c;
	}
	@Override
	public void performAction(float arg0,  net.java.games.input.Event e) {
		// TODO Auto-generated method stub
		//Vector3D keepingDir = camera.getRightAxis().normalize(); // .getViewDirection().normalize();
		//Vector3D vDir = camera.getUpAxis();
		//Vector3D nDir = camera.getViewDirection();
		
		
		Matrix3D roll;
		//if (e.getValue()<-.2|| e.getComponent().getName().equals("Up")){
			roll = new Matrix3D(0.05*(double)arg0,camera.getRightAxis().normalize());
		//}
		//else if (e.getValue()>.2){
		//	roll = new Matrix3D(-0.05*(double)arg0,camera.getRightAxis().normalize());
		//} else{
		//	roll = new Matrix3D(0.0*(double)arg0,camera.getRightAxis().normalize());
		//}
		
		camera.setAxes(camera.getRightAxis().normalize(), camera.getUpAxis().mult(roll), camera.getViewDirection().mult(roll));
		//System.out.println(roll.toString());
		//System.out.println(vDir.getY());
		//System.out.println(vDir.toString());
		//vDir.mult(roll);
		//System.out.println(vDir.getY());
		//nDir.mult(roll);
		
		
	}

}
