package myGameEngine.commands;

import a3.Player.Avatar;
import graphicslib3D.Matrix3D;
import graphicslib3D.Vector3D;
import myGameEngine.Camera3Pcontroller;
import net.java.games.input.Event;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;
import sage.scene.Group;
import sage.scene.TriMesh;

public class OrbitAroundAction extends AbstractInputAction {
	private Camera3Pcontroller cam;
	private boolean shift;
	private Group av;
	
	public OrbitAroundAction (Camera3Pcontroller cam, Group av2){
		this.cam=cam;
		this.av=av2;
	}
	public void setCam(Camera3Pcontroller c){
		cam=c;
	}
	
	public void performAction(float time, Event evt)
	{
		float rotAmount;
		//System.out.println(evt.getValue());
		
//		if (shift){
//			System.out.println("shifted");
//		}
		if (evt.getValue() < -0.3 || evt.getComponent().getName().equals("Left")) { rotAmount=-1.0f; }
		else { if (evt.getValue() > 0.3||evt.getComponent().getName().equals("Right")) { rotAmount=1.0f; }
		else { rotAmount=0.0f; }
		}
	
		cam.setCameraAzimuth(cam.getCameraAzimuth() + 
			rotAmount) ;
		cam.setCameraAzimuth(cam.getCameraAzimuth() % 360) ;
		if (isShift()){
			Matrix3D roll = new Matrix3D(rotAmount,new Vector3D(0,1,0));
			float degrees = .3f;
			Vector3D vec = new Vector3D(0,1,0);
			//float[] a = av.getPhysicsObject().getAngularVelocity();
			//a[1] = 5;  //0 did nothing 
			//a[2] = 5;
			//a[0] = 5;
			//for (int i = 0; i<a.length; i++){
			//	System.out.println(a[i]);
			//}
			//System.out.println();
			//av.getPhysicsObject().setAngularVelocity(a);;
			av.rotate(rotAmount, vec);
			//av.setHeading1(rotAmount, vec);
		//	av.setLocalRotation(roll);
	//		av.setLocalRotation(av.getLocalRotation().rotate(degrees , new Vector3D(0,1,0)));
		}
	}
	public boolean isShift() {
		return shift;
	}
	public void setShift(boolean shift) {
		this.shift = shift;
	} 
	
}
