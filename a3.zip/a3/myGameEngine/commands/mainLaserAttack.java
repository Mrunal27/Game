package myGameEngine.commands;

import net.java.games.input.Event;
import sage.input.action.AbstractInputAction;

public class mainLaserAttack extends AbstractInputAction {

	@Override
	public void performAction(float arg0, Event arg1) {
		// TODO Auto-generated method stub

	}

}
