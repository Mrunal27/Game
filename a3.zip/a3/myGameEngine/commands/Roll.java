package myGameEngine.commands;

import graphicslib3D.Matrix3D;
import graphicslib3D.Vector3D;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;

public class Roll extends AbstractInputAction {
	private ICamera camera;
	
	public Roll(ICamera c){
		camera = c;
	}
	
	@Override
	public void performAction(float arg0,  net.java.games.input.Event e) {
		// TODO Auto-generated method stub
		Vector3D keepingDir = camera.getViewDirection().normalize(); // .getViewDirection().normalize();
		Vector3D uDir = camera.getRightAxis();
		Vector3D vDir = camera.getUpAxis();
		
		
		Matrix3D roll;
		//if (e.getValue()<-.2|| e.getComponent().getName().equals("Q")){
			roll = new Matrix3D(0.1*(double)arg0,keepingDir);
		//}
		//else if (e.getValue()>.2){
		//	roll = new Matrix3D(-0.1*(double)arg0,keepingDir);
		//} else{
		//	roll = new Matrix3D(0.0*(double)arg0,keepingDir);
		//}
		camera.setAxes(uDir.mult(roll), vDir.mult(roll), keepingDir);
		
	}

}
