package myGameEngine.commands;

import a3.Player.Avatar;
import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;

public class Backward extends AbstractInputAction {
	//camera = c;
	//runAction = r;
	private Avatar av;
	
	
	 public Backward(Avatar av) //, SetSpeedAction r)
	 { this.av = av;
	 //runAction = r;
	 }
	
	@Override
	public void performAction(float arg0, net.java.games.input.Event e) {
		// TODO Auto-generated method stub
		float moveAmount ;
		//if (runAction.isRunning()){
		//	moveAmount = (float) 0.5 ; 
		//}
		//else{
			moveAmount = (float) 0.005 ; 
		//}
			/*
			 * This section contains code supplied by Dr Gordon
			 */
		Vector3D viewDir = av.getHeading();  
		Point3D p = new Point3D(av.getLocalTranslation().getValues());
		Vector3D curLocVector = new Vector3D(p);
		Vector3D newLocVec;
			//System.out.println(e.getComponent().getName());
		
		//if(e.getValue()<-0.2 || e.getComponent().getName().equals("W")){
		/*newLocVec = curLocVector.add(viewDir.mult(moveAmount*arg0));*/
		//}
		System.out.println(e.getValue() + "backward");
		if (e.getValue()>0.2  || e.getComponent().getName().equals("S")){//*/
			newLocVec = curLocVector.minus(viewDir.mult(moveAmount*arg0));
			double newX = newLocVec.getX();
			double newY = newLocVec.getY();
			double newZ = newLocVec.getZ();
			Point3D newLoc = new Point3D(newX, newY, newZ);
			av.getLocalTranslation().translate(newX, newY, newZ);
			
		}// else{
		/*	newLocVec = curLocVector;*/
		//}
		//camera.setLocation(newLoc);
	}

}
