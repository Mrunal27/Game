package myGameEngine.commands;

import a3.Player.Avatar;
import graphicslib3D.Matrix3D;
import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import sage.camera.ICamera;
import sage.input.action.AbstractInputAction;
import sage.scene.Group;
import sage.scene.TriMesh;
import sage.terrain.*;

public class Pan extends AbstractInputAction {
	private ICamera camera;
	private Group av;
	private TerrainBlock terrain;
	
	
	public Pan(Group av2, TerrainBlock ter){
		this.av = av2;
		this.terrain = ter;
	}
	@Override
	public void performAction(float arg0, net.java.games.input.Event e) {
		// TODO Auto-generated method stub
		Float moveAmount;
		moveAmount= (float) 0.005;
		
		/*
		 * This section contains code supplied by Dr Gordon
		 */
		//Vector3D viewDir = camera.getRightAxis().normalize(); // .getViewDirection().normalize();
		//Vector3D curLocVector = new Vector3D(camera.getLocation());
		//Vector3D newLocVec;
		//if(e.getValue()<-0.2 || e.getComponent().getName().equals("A")){
		//	newLocVec = curLocVector.minus(viewDir.mult(moveAmount*arg0));
		//}
		//else if (e.getValue()>0.2 && e.getComponent().getName().equals("X Axis") || e.getComponent().getName().equals("D")){
		//	newLocVec = curLocVector.add(viewDir.mult(moveAmount*arg0));
		//} else{
		//	newLocVec = curLocVector;
		//}
		//System.out.println(e.getComponent().getName());
		//double newX = newLocVec.getX();
		//double newY = newLocVec.getY();
		//double newZ = newLocVec.getZ();
		//Point3D newLoc = new Point3D(newX, newY, newZ);
		//camera.setLocation(newLoc);
		if(e.getValue()<-0.3 || e.getComponent().getName().equals("A")){
			//newLocVec = curLocVector.add(viewDir.normalize().mult(moveAmount*arg0));
			//double newX = newLocVec.getX();
			//double newY = newLocVec.getY();
			//double newZ = newLocVec.getZ();
			//Point3D newLoc = new Point3D(newX, newY, newZ);
			//Matrix3D temp = new Matrix3D(newLoc.getX(),newLoc.getY(), newLoc.getZ());
			/*Matrix3D rot  = av.getHeading1();
			Vector3D dir=new Vector3D(1,0,0);
			dir=dir.mult(rot);
			dir.scale(.1);
			av.translate((float)dir.getX(), (float)dir.getY(), (float)dir.getZ());
			updateVerticalPosition();
			//av.getLocalTranslation().translate(newX, newY, newZ);
			//*/
			
			float[] a = av.getPhysicsObject().getLinearVelocity();
			
			//System.out.println(a[1]); //0 was 0, 1 = pos might be up
			a[0]=a[0]+.1f;
			//IPhysicsObject b = av.getPhysicsObject();
			
			av.getPhysicsObject().setLinearVelocity(a);
			
		}//	/*
		//else if ((e.getValue()>0.2 && e.getComponent().getName().equals("Y Axis"))  || e.getComponent().getName().equals("S")&e.getValue()==1.0){
		//	newLocVec = curLocVector.minus(viewDir.mult(moveAmount*arg0));
		else if (e.getValue()>0.3  || e.getComponent().getName().equals("D")){
			//newLocVec = curLocVector.minus(viewDir.normalize().mult(moveAmount*arg0));
			//double newX = newLocVec.getX();
			//double newY = newLocVec.getY();
			//double newZ = newLocVec.getZ();
			//Point3D newLoc = new Point3D(newX, newY, newZ);
			//av.getLocalTranslation().translate(newX, newY, newZ);
			
			/*Matrix3D rot  = av.getHeading1();
			Vector3D dir=new Vector3D(-1,0,0);
			dir=dir.mult(rot);
			dir.scale(.1);
			av.translate((float)dir.getX(), (float)dir.getY(), (float)dir.getZ());
			//*/
			
float[] a = av.getPhysicsObject().getLinearVelocity();
			
			//System.out.println(a[1]); //0 was 0, 1 = pos might be up
			a[0]=a[0]-.1f;
			//IPhysicsObject b = av.getPhysicsObject();
			
			av.getPhysicsObject().setLinearVelocity(a);
			//updateVerticalPosition();
		}
	}
	
	private void updateVerticalPosition(){
		Point3D avLoc = new Point3D(av.getLocalTranslation().getCol(3));
		float x = (float) avLoc.getX();
		float z = (float) avLoc.getZ();
		//if (terrain==null){System.out.println("terHeight is null");}
		//System.out.println(x + " "+ z);
		
		//System.out.println(terrain.getSize());
		float terHeight = terrain.getHeight(x,z);
		float desiredHeight = terHeight + (float)terrain.getOrigin().getY() + 0.5f;
		av.getLocalTranslation().setElementAt(1, 3, desiredHeight);
	}

}
