package myGameEngine.commands;

import myGameEngine.Camera3Pcontroller;
import net.java.games.input.Event;
import sage.input.action.AbstractInputAction;

public class OrbitElevation extends AbstractInputAction {
	private Camera3Pcontroller cam;
	
	public OrbitElevation(Camera3Pcontroller cam){
		this.cam=cam;
	}
	@Override
	public void performAction(float elespetime, Event evt) {
		// TODO Auto-generated method stub
		float eleAmount;
		 //System.out.println(evt.getValue());
		 if ((evt.getValue() < -0.3 || evt.getComponent().getName().equals("Up"))&& cam.getCameraElevation()<80f) { eleAmount=-0.1f; }
		 else { if ((evt.getValue() > 0.3 ||evt.getComponent().getName().equals("Down")) && cam.getCameraElevation()>-80f) { eleAmount=0.1f; }
		 else { eleAmount=0.0f; }
		 }
		 
		 cam.setCameraElevation(cam.getCameraElevation()+eleAmount) ;
		 cam.setCameraElevation(cam.getCameraElevation() % 81) ;
		
	}

}
