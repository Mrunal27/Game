package myGameEngine.nodeController;

import graphicslib3D.Matrix3D;
import graphicslib3D.Vector3D;
import sage.scene.Controller;
import sage.scene.SceneNode;

public class moonrotater extends Controller {
	private boolean needed = true;
	private Vector3D rotationAxis = new Vector3D(0,0,1);
	private double rotationRate=.1;
	
	public void isNeeded(){
		needed=true;
	}
	@Override
	public void update(double time) {
		// TODO Auto-generated method stub
		// compute amount to rotate based on rotationRate being degrees/second
		// and time being millisecs
		if (needed){
			
			double rotAmount = rotationRate/10.0 * time ;
			//compute a new rotation transform
			Matrix3D newRot = new Matrix3D(rotAmount, rotationAxis);
			//add the rotation to the local transform of every controlled node
			//System.out.println(controlledNodes.size());
			for (SceneNode node : controlledNodes){ 
				//get node�s current rotation
				//System.out.println(node.getClass());
				if(node!=null){
					Matrix3D curRot = node.getLocalRotation();
					//add new rotation into node�s current local rotation
					curRot.concatenate(newRot);
					node.setLocalRotation(curRot);
				}
			}
		}
	}

}
