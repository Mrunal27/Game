package myGameEngine.nodeController;

import a3.DogHouse;
import graphicslib3D.Matrix3D;
import sage.scene.Controller;

public class Doubler extends Controller {
	private double starttime;
	private DogHouse dh;
	boolean needed = false;
	
//	private double 1000.0;
	
	public Doubler(DogHouse dh){
		this.dh=dh;
		
	}
	public void setStarttime(float elapsedTimeMS){
		//starttime=elapsedTimeMS;
		needed=true;
	}
	
	@Override
	public void update(double arg0) {
		// TODO Auto-generated method stub
		//System.out.println(arg0);
		if ((starttime)>1000&&needed){
			Matrix3D temp = new Matrix3D();
			int scale=5;
			temp.scale(scale, scale, scale);
			dh.setLocalScale(temp);
			needed=false;
			starttime=0;
		} else if (needed) {
			starttime+=arg0;
			Matrix3D temp = new Matrix3D();
			int scale=10;
			temp.scale(scale, scale, scale);
			dh.setLocalScale(temp);
		}
	}

}
