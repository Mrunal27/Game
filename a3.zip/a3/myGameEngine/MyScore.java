package myGameEngine;

import sage.scene.HUDString;

public class MyScore extends HUDString {
	
	public MyScore(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
