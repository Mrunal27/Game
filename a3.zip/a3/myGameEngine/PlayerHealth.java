package myGameEngine;

import myGameEngine.network.MyClient;

public class PlayerHealth {

	//double armor=100, shield = 100;
	double currentShield=100, currentArmor=100;
	public boolean life = true;

	public void PlayerHealthUpdate(float elapsedTimeMS,MyClient myClient) {
		// TODO Auto-generated constructor stub
		//System.out.println("Time: "+elapsedTimeMS);
		if(currentShield>0){
			currentShield -= 0.01*elapsedTimeMS;
			System.out.println("Current Shield: "+currentShield);
		}

		if(currentShield<0 && currentArmor>0){
			currentArmor -= 0.01*elapsedTimeMS;
			System.out.println("Current Armor: "+currentArmor);
		}
		
		if(100%10 < currentShield || 100%10 < currentArmor){
			//System.out.println("Shield and Armor");
			if(myClient!=null){
			myClient.sendPlayerHealth(currentShield, currentArmor,life);
			}
		}else{
			life = false;
			if (myClient!=null){
			myClient.sendPlayerHealth(currentShield, currentArmor,life);
			}
		}
	
	}
	
	public double getShield(){
		return currentShield;
	}
	
	public double getArmor(){
		return currentArmor;
	}
	public void setArmor(double add){
		currentArmor+=add;
		if (currentArmor > 100){
			System.out.println(currentArmor);
			currentArmor =100;
		}
	}
}
